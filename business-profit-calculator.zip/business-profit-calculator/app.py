"""Professional Daily Business Profit Calculator: application factory and entry point."""
import logging
import os
from datetime import date

from dotenv import load_dotenv
from flask import Flask, g, render_template, request, session

import db as database
from config import BASE_DIR, build_config
from models import settings as settings_model
from models import user as user_model
from services import formatting
from services.security import init_security
from services.validators import BUSINESS_TYPES, EXPENSE_CATEGORIES, PAYMENT_METHODS

ERROR_MESSAGES = {
    400: ("Request couldn't be verified",
          "Your session may have expired or the form was invalid. Go back, refresh the page and try again."),
    403: ("Not allowed", "You don't have permission to view this page."),
    405: ("Method not allowed", "This page can't be opened that way."),
    413: ("Request too large", "The data you sent was too large."),
    429: ("Too many attempts", "Wait a few minutes and try again."),
    500: ("Something went wrong", "An unexpected error occurred. Your data was not changed. Please try again."),
}


def create_app(test_config=None):
    load_dotenv(os.path.join(BASE_DIR, ".env"))
    app = Flask(__name__)
    app.config.update(build_config())
    if test_config:
        app.config.update(test_config)

    if app.config.get("SECRET_KEY_GENERATED") and not app.testing:
        logging.getLogger(__name__).warning(
            "SECRET_KEY is not set. Using a temporary key: you will be signed out on restart. "
            "Copy .env.example to .env and set SECRET_KEY."
        )

    os.makedirs(os.path.dirname(app.config["DATABASE"]), exist_ok=True)
    database.init_app(app)
    init_security(app)
    formatting.init_app(app)

    from routes import auth, dashboard, expenses, reports, sales, settings, transactions

    for module in (auth, dashboard, sales, expenses, transactions, reports, settings):
        app.register_blueprint(module.bp)

    @app.before_request
    def load_user():
        g.user = None
        g.settings = None
        if request.endpoint == "static":
            return
        user_id = session.get("user_id")
        if user_id is None:
            return
        conn = database.get_db()
        user = user_model.get_by_id(conn, user_id)
        if user is None:
            session.pop("user_id", None)
            return
        g.user = user
        g.settings = settings_model.get(conn, user["id"])

    @app.context_processor
    def inject_globals():
        return {
            "today_iso": date.today().isoformat(),
            "currency_symbol": formatting.symbol_for(g.settings["currency"]).strip() if g.get("settings") else "",
            "all_payment_methods": PAYMENT_METHODS,
            "all_categories": EXPENSE_CATEGORIES,
            "all_business_types": BUSINESS_TYPES,
        }

    def make_handler(code):
        def handler(_error):
            title, message = ERROR_MESSAGES.get(code, ("Error", "Something went wrong."))
            return render_template("error.html", code=code, title=title, message=message), code
        return handler

    for code in ERROR_MESSAGES:
        app.register_error_handler(code, make_handler(code))

    @app.errorhandler(404)
    def not_found(_error):
        return render_template("404.html"), 404

    return app


if __name__ == "__main__":
    application = create_app()
    application.run(host="127.0.0.1", port=5000, debug=application.config["DEBUG"])
