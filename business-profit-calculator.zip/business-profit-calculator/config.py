"""Application configuration. Secrets are read from environment variables."""
import os
import secrets
from datetime import timedelta

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


def _env_bool(name, default=False):
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def build_config():
    """Build the config dict. Call after the .env file has been loaded."""
    secret = os.environ.get("SECRET_KEY", "").strip()
    generated = False
    if not secret or secret.startswith("replace-me"):
        # No usable key configured: use a random one for this run only.
        # Sessions will be reset whenever the server restarts.
        secret = secrets.token_hex(32)
        generated = True

    database = os.environ.get("DATABASE_PATH", "").strip()
    if not database:
        database = os.path.join(BASE_DIR, "instance", "profit_calculator.db")
    elif not os.path.isabs(database):
        database = os.path.join(BASE_DIR, database)

    return {
        "SECRET_KEY": secret,
        "SECRET_KEY_GENERATED": generated,
        "DATABASE": database,
        "DEBUG": _env_bool("FLASK_DEBUG", False),
        "SESSION_COOKIE_HTTPONLY": True,
        "SESSION_COOKIE_SAMESITE": "Lax",
        "SESSION_COOKIE_SECURE": _env_bool("SESSION_COOKIE_SECURE", False),
        "PERMANENT_SESSION_LIFETIME": timedelta(hours=8),
        "MAX_CONTENT_LENGTH": 1024 * 1024,
        "CSRF_ENABLED": True,
        "PER_PAGE": 15,
        "LOGIN_MAX_ATTEMPTS": 5,
        "LOGIN_WINDOW_SECONDS": 300,
        "MAX_RANGE_DAYS": 366,
    }
