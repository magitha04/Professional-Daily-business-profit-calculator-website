# Professional Daily Business Profit Calculator

A web app for shopkeepers, retailers, freelancers and small business owners to record daily sales and
expenses and see profit or loss instantly. Built with Flask, SQLite, Bootstrap 5 and Chart.js.

## Features

- Register, sign in and sign out. Each user only ever sees their own data.
- Dashboard with eight summary cards (sales, cost of goods, expenses, gross profit, net profit or loss,
  margin, transactions, best seller) and date filters: today, yesterday, last 7 days, last 30 days, custom range.
- Sales entry with live preview, expense tracking with categories, search, filters, sorting, pagination,
  edit and delete (with confirmation).
- Transaction history that combines sales and expenses.
- Five charts from real database data: daily profit line, sales vs expenses, monthly profit, expense categories, top products.
- Daily, weekly, monthly and custom profit and loss reports, CSV export, and print or save as PDF.
- Business settings (name, type, currency, address, date format), light and dark mode, demo data tools.

## Prerequisites

- Python 3.9 or newer (check with `python --version`; on macOS/Linux you may need `python3`).
- An internet connection in the browser: Bootstrap, Bootstrap Icons, Chart.js and the IBM Plex Sans font load
  from public CDNs (free, no account). Without internet the app still works but looks unstyled and charts won't draw.

## Setup (Windows, macOS, Linux)

```bash
# 1. Open a terminal in the project folder
cd business-profit-calculator

# 2. Create a virtual environment
python -m venv venv

# 3. Activate it
#    Windows (Command Prompt):  venv\Scripts\activate
#    Windows (PowerShell):      venv\Scripts\Activate.ps1
#    macOS / Linux:             source venv/bin/activate

# 4. Install dependencies
pip install -r requirements.txt

# 5. Configure environment variables
#    macOS/Linux: cp .env.example .env      Windows: copy .env.example .env
#    Then generate a secret key and paste it after SECRET_KEY= in .env:
python -c "import secrets; print(secrets.token_hex(32))"

# 6. Initialise the database (optional: it is also created automatically on first start)
flask --app app init-db

# 7. Optional: create a demo user with about six weeks of sample data
python seed.py
#    The command prints a random password. Or choose your own:
#    python seed.py --username demo --password "YourPass123"

# 8. Start the server
python app.py
```

Open **http://127.0.0.1:5000** in your browser, register an account (or sign in as the demo user) and start.

Set `FLASK_DEBUG=1` in `.env` while developing to get auto-reload. Never use it on a public server.

## Demo data

- Add: `python seed.py` or Settings > Load demo data.
- Remove: `python seed.py --clear --username demo` or Settings > Clear demo data.
  Only records flagged as demo are deleted. Anything you entered yourself is kept.
  Add `--delete-user` to also remove an empty demo account.

## Database and migrations

- `schema.sql` creates `users`, `business_settings`, `sales`, `expenses` and `schema_migrations`.
  It is safe to run repeatedly (`flask --app app init-db`).
- To change the schema later, add a numbered SQL file such as `migrations/001_add_notes_column.sql`
  and run `flask --app app migrate` (they also apply automatically at start-up). Each file runs once.
- Money is stored as integer paise/cents and quantities as thousandths, so there is no floating-point drift.
  Foreign keys are enforced and every query is parameterised.
- Reset everything: stop the app and delete `instance/profit_calculator.db`.

## Formulas (the same code powers dashboard, charts, history and reports)

| Quantity | Formula |
|---|---|
| Gross sales | quantity x selling price |
| Net sales | gross sales - discount |
| Cost of goods sold | quantity x cost price |
| Gross profit | net sales - cost of goods sold |
| Net profit | gross profit - total expenses |
| Margin % | net profit / net sales x 100 (shown as N/A when net sales is zero) |

Discount is a total amount for the sale line. All totals are calculated on the server; values sent by the browser are ignored.

## Running the tests

```bash
python -m unittest discover -s tests -v
# or, if you installed pytest:  pip install pytest && pytest
```

76 tests cover calculations, validation, authentication, route protection, CSRF, cross-user isolation,
CRUD, filters, reports matching the dashboard, CSV export and settings.

## Project structure

```
business-profit-calculator/
├── app.py                 application factory and entry point
├── config.py              settings read from environment variables
├── db.py                  SQLite connection, schema init, migrations, CLI commands
├── schema.sql             database schema
├── seed.py                demo data tool
├── models/                data access: user, settings, sale, expense, transaction
├── routes/                blueprints: auth, dashboard, sales, expenses, transactions, reports, settings
├── services/              profit_calculator (formulas), money, validators, security, analytics,
│                          reports, demo_data, date_ranges, formatting
├── templates/             Jinja pages and macros
├── static/                css, js (main, dashboard, sales, reports, theme)
├── migrations/            optional numbered SQL migrations
├── docs/PROJECT_ABSTRACT.md
└── tests/
```

## Security notes

Passwords are hashed (scrypt via Werkzeug). Forms carry CSRF tokens; create, update, delete and logout are POST-only.
Sessions use HttpOnly, SameSite=Lax cookies (set `SESSION_COOKIE_SECURE=1` behind HTTPS). Every query filters by the
signed-in user's id. Inputs are validated and cleaned, output is escaped, CSV exports neutralise spreadsheet formulas,
failed logins are rate limited, and security headers including a Content-Security-Policy are sent.

## Troubleshooting

| Problem | Fix |
|---|---|
| `python` not found | Use `python3`, or reinstall Python and tick "Add to PATH" on Windows. |
| PowerShell blocks `Activate.ps1` | Run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, or use Command Prompt. |
| `ModuleNotFoundError: flask` | Activate the virtual environment, then `pip install -r requirements.txt`. |
| `Address already in use` (port 5000) | Close the other program (on macOS, turn off AirPlay Receiver) or edit the port at the bottom of `app.py`. |
| Signed out after every restart | Set `SECRET_KEY` in `.env`. |
| Page looks unstyled or charts are blank | The CDNs are unreachable. Check your internet connection or firewall. |
| "Request couldn't be verified" | The session expired. Refresh the page and submit again. |
| "Too many failed attempts" | Wait 5 minutes. |
| `database is locked` | Close other programs using the .db file and retry. |

## Known limitations

- Single-currency per account: changing currency changes the symbol only and does not convert stored amounts.
- Discount is an amount, not a percentage. Taxes (GST/VAT), returns, stock levels and invoices are not modelled.
- Login throttling is kept in memory, so it resets on restart and is per server process.
- No email verification or password reset by email (it would need an email service).
- Uses Flask's development server. For real deployment run it behind a production server such as gunicorn or waitress with HTTPS.
- Bootstrap, Chart.js and fonts come from CDNs without integrity hashes. Download them into `static/` for offline use.
- Charts use floating-point numbers for display only. All calculations use integers.
- The browser's visual rendering and the charts could not be viewed in the build environment; they were checked through
  their data endpoints, JavaScript syntax checks and HTML responses.
