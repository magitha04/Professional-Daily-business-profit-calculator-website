"""Dashboard summary cards and chart data."""
from flask import Blueprint, current_app, g, jsonify, redirect, render_template, request, url_for

from db import get_db
from models import sale as sale_model
from services.analytics import build_chart_data
from services.date_ranges import resolve_range
from services.profit_calculator import build_period_summary
from services.security import login_required

bp = Blueprint("dashboard", __name__)


@bp.route("/")
def home():
    return redirect(url_for("dashboard.index"))


@bp.route("/dashboard")
@login_required
def index():
    rng = resolve_range(request.args, max_days=current_app.config["MAX_RANGE_DAYS"])
    db = get_db()
    summary = build_period_summary(db, g.user["id"], rng.start, rng.end)
    best = sale_model.top_products(db, g.user["id"], rng.start, rng.end, limit=1)
    return render_template("dashboard.html", rng=rng, summary=summary,
                           best_product=best[0] if best else None)


@bp.route("/dashboard/data")
@login_required
def data():
    rng = resolve_range(request.args, max_days=current_app.config["MAX_RANGE_DAYS"])
    payload = build_chart_data(get_db(), g.user["id"], rng.start, rng.end,
                               g.settings["currency"], g.settings["date_format"])
    return jsonify(payload)
