"""Expense entry, listing, editing and deleting."""
from datetime import date

from flask import (Blueprint, abort, current_app, flash, g, redirect, render_template,
                   request, url_for)

from db import get_db
from models import expense as expense_model
from services.formatting import plain_amount
from services.security import consume_form_nonce, login_required, safe_next
from services.validators import (EXPENSE_CATEGORIES, PAYMENT_METHODS, parse_list_filters,
                                 validate_expense, with_args)

bp = Blueprint("expenses", __name__, url_prefix="/expenses")


def _row_values(row):
    return {
        "expense_date": row["expense_date"], "category": row["category"],
        "description": row["description"], "amount": plain_amount(row["amount_minor"]),
        "payment_method": row["payment_method"], "notes": row["notes"],
    }


def _form_context(values, errors, expense):
    return dict(values=values, errors=errors, expense=expense, categories=EXPENSE_CATEGORIES,
                payment_methods=PAYMENT_METHODS, today=date.today().isoformat())


@bp.route("/")
@login_required
def list_expenses():
    filters = parse_list_filters(request.args, {"date", "amount", "category"})
    category = request.args.get("category", "")
    category = category if category in EXPENSE_CATEGORIES else ""
    rows, pager = expense_model.list_page(
        get_db(), g.user["id"], q=filters["q"], start=filters["start"], end=filters["end"],
        payment=filters["payment"], category=category, sort=filters["sort"],
        direction=filters["dir"], page=filters["page"], per_page=current_app.config["PER_PAGE"],
    )
    filters["category"] = category
    with_args(filters)
    return render_template("expenses.html", expenses=rows, pager=pager, filters=filters,
                           categories=EXPENSE_CATEGORIES, payment_methods=PAYMENT_METHODS)


@bp.route("/add", methods=["GET", "POST"])
@login_required
def add():
    errors = {}
    values = {"expense_date": date.today().isoformat(), "payment_method": "Cash"}
    if request.method == "POST":
        clean, values, errors = validate_expense(request.form)
        if not errors:
            if not consume_form_nonce(request.form.get("form_nonce")):
                flash("That expense was already submitted. Check the list before adding it again.", "warning")
                return redirect(url_for("expenses.list_expenses"))
            expense_model.create(get_db(), g.user["id"], clean)
            flash("Expense saved.", "success")
            return redirect(url_for("expenses.list_expenses"))
        flash("Please fix the highlighted fields.", "danger")
    return render_template("add_expense.html", **_form_context(values, errors, None))


@bp.route("/<int:expense_id>/edit", methods=["GET", "POST"])
@login_required
def edit(expense_id):
    db = get_db()
    expense = expense_model.get(db, g.user["id"], expense_id)
    if expense is None:
        abort(404)
    errors, values = {}, _row_values(expense)
    if request.method == "POST":
        clean, values, errors = validate_expense(request.form)
        if not errors:
            expense_model.update(db, g.user["id"], expense_id, clean)
            flash("Expense updated.", "success")
            return redirect(url_for("expenses.list_expenses"))
        flash("Please fix the highlighted fields.", "danger")
    return render_template("add_expense.html", **_form_context(values, errors, expense))


@bp.route("/<int:expense_id>/delete", methods=["POST"])
@login_required
def delete(expense_id):
    if expense_model.delete(get_db(), g.user["id"], expense_id):
        flash("Expense deleted.", "success")
    else:
        abort(404)
    return redirect(safe_next(request.form.get("next")) or url_for("expenses.list_expenses"))
