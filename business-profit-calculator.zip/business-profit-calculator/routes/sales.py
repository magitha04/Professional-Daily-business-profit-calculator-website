"""Sales entry, listing, editing and deleting."""
from datetime import date

from flask import (Blueprint, abort, current_app, flash, g, redirect, render_template,
                   request, url_for)

from db import get_db
from models import sale as sale_model
from services.formatting import format_quantity, plain_amount
from services.security import consume_form_nonce, login_required, safe_next
from services.validators import PAYMENT_METHODS, parse_list_filters, validate_sale, with_args

bp = Blueprint("sales", __name__, url_prefix="/sales")


def _row_values(row):
    return {
        "sale_date": row["sale_date"], "product_name": row["product_name"],
        "quantity": format_quantity(row["quantity_milli"]),
        "selling_price": plain_amount(row["selling_price_minor"]),
        "cost_price": plain_amount(row["cost_price_minor"]),
        "discount": plain_amount(row["discount_minor"]),
        "payment_method": row["payment_method"], "customer_name": row["customer_name"],
        "notes": row["notes"],
    }


@bp.route("/")
@login_required
def list_sales():
    filters = with_args(parse_list_filters(request.args, {"date", "amount", "profit", "product"}))
    rows, pager = sale_model.list_page(
        get_db(), g.user["id"], q=filters["q"], start=filters["start"], end=filters["end"],
        payment=filters["payment"], sort=filters["sort"], direction=filters["dir"],
        page=filters["page"], per_page=current_app.config["PER_PAGE"],
    )
    return render_template("sales.html", sales=rows, pager=pager, filters=filters,
                           payment_methods=PAYMENT_METHODS)


@bp.route("/add", methods=["GET", "POST"])
@login_required
def add():
    errors = {}
    values = {"sale_date": date.today().isoformat(), "discount": "0", "payment_method": "Cash"}
    if request.method == "POST":
        clean, values, errors = validate_sale(request.form)
        if not errors:
            if not consume_form_nonce(request.form.get("form_nonce")):
                flash("That sale was already submitted. Check the list before adding it again.", "warning")
                return redirect(url_for("sales.list_sales"))
            sale_model.create(get_db(), g.user["id"], clean)
            flash("Sale saved.", "success")
            return redirect(url_for("sales.list_sales"))
        flash("Please fix the highlighted fields.", "danger")
    return render_template("add_sale.html", values=values, errors=errors, sale=None,
                           payment_methods=PAYMENT_METHODS, today=date.today().isoformat())


@bp.route("/<int:sale_id>/edit", methods=["GET", "POST"])
@login_required
def edit(sale_id):
    db = get_db()
    sale = sale_model.get(db, g.user["id"], sale_id)
    if sale is None:
        abort(404)
    errors, values = {}, _row_values(sale)
    if request.method == "POST":
        clean, values, errors = validate_sale(request.form)
        if not errors:
            sale_model.update(db, g.user["id"], sale_id, clean)
            flash("Sale updated.", "success")
            return redirect(url_for("sales.list_sales"))
        flash("Please fix the highlighted fields.", "danger")
    return render_template("add_sale.html", values=values, errors=errors, sale=sale,
                           payment_methods=PAYMENT_METHODS, today=date.today().isoformat())


@bp.route("/<int:sale_id>/delete", methods=["POST"])
@login_required
def delete(sale_id):
    if sale_model.delete(get_db(), g.user["id"], sale_id):
        flash("Sale deleted.", "success")
    else:
        abort(404)
    return redirect(safe_next(request.form.get("next")) or url_for("sales.list_sales"))
