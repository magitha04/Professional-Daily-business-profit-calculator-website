"""Registration, login and logout."""
import sqlite3

from flask import (Blueprint, current_app, flash, g, redirect, render_template,
                   request, session, url_for)

from db import get_db
from models import user as user_model
from services.security import login_required, safe_next
from services.validators import validate_registration

bp = Blueprint("auth", __name__)


@bp.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("dashboard.index"))
    values, errors = {}, {}
    if request.method == "POST":
        values, password, errors = validate_registration(request.form)
        db = get_db()
        if not errors:
            if user_model.exists(db, username=values["username"]):
                errors["username"] = "That username is already taken."
            if user_model.exists(db, email=values["email"]):
                errors["email"] = "An account with that email already exists."
        if not errors:
            try:
                user_model.create_user(db, values["username"], values["email"],
                                       values["full_name"], password)
            except sqlite3.IntegrityError:
                errors["username"] = "That username or email is already registered."
            else:
                flash("Account created. Sign in to start tracking your profit.", "success")
                return redirect(url_for("auth.login"))
        flash("Please fix the highlighted fields.", "danger")
    return render_template("register.html", values=values, errors=errors)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("dashboard.index"))
    next_url = safe_next(request.values.get("next"))
    if request.method == "POST":
        login_name = (request.form.get("login") or "").strip()
        password = request.form.get("password") or ""
        throttle = current_app.extensions["login_throttle"]
        if throttle.blocked(login_name):
            flash("Too many failed attempts. Wait a few minutes and try again.", "danger")
            return render_template("login.html", next_url=next_url, login_value=login_name), 429
        user = user_model.authenticate(get_db(), login_name, password) if login_name else None
        if user is None:
            throttle.record_failure(login_name)
            flash("Incorrect username or password.", "danger")
            return render_template("login.html", next_url=next_url, login_value=login_name), 401
        throttle.reset(login_name)
        session.clear()
        session.permanent = True
        session["user_id"] = user["id"]
        return redirect(next_url or url_for("dashboard.index"))
    return render_template("login.html", next_url=next_url, login_value="")


@bp.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    flash("You have been signed out.", "info")
    return redirect(url_for("auth.login"))
