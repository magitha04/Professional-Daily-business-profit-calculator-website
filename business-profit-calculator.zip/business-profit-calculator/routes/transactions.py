"""Combined transaction history for sales and expenses."""
from datetime import date

from flask import Blueprint, Response, current_app, g, render_template, request

from db import get_db
from models import transaction as transaction_model
from services.reports import transactions_to_csv
from services.security import login_required
from services.validators import PAYMENT_METHODS, parse_list_filters, with_args

bp = Blueprint("transactions", __name__, url_prefix="/transactions")


def _filters():
    filters = parse_list_filters(request.args, {"date", "amount", "profit", "product", "category"})
    kind = request.args.get("type", "")
    filters["type"] = kind if kind in ("sale", "expense") else ""
    return with_args(filters)


@bp.route("/")
@login_required
def history():
    filters = _filters()
    rows, pager = transaction_model.list_page(
        get_db(), g.user["id"], q=filters["q"], start=filters["start"], end=filters["end"],
        kind=filters["type"], payment=filters["payment"], sort=filters["sort"],
        direction=filters["dir"], page=filters["page"], per_page=current_app.config["PER_PAGE"],
    )
    return render_template("transactions.html", rows=rows, pager=pager, filters=filters,
                           payment_methods=PAYMENT_METHODS)


@bp.route("/export.csv")
@login_required
def export_csv():
    filters = _filters()
    rows = transaction_model.list_all(
        get_db(), g.user["id"], q=filters["q"], start=filters["start"], end=filters["end"],
        kind=filters["type"], payment=filters["payment"], sort=filters["sort"],
        direction=filters["dir"],
    )
    body = transactions_to_csv(rows, g.settings["date_format"])
    name = "transactions-%s.csv" % date.today().isoformat()
    return Response(body, mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="%s"' % name})
