"""Daily, weekly, monthly and custom profit and loss reports."""
from datetime import date

from flask import Blueprint, Response, current_app, g, render_template, request

from db import get_db
from services.date_ranges import REPORT_TYPES, resolve_report_range
from services.reports import build_report, export_period_csv
from services.security import login_required

bp = Blueprint("reports", __name__, url_prefix="/reports")


def _range():
    return resolve_report_range(request.args, max_days=current_app.config["MAX_RANGE_DAYS"])


@bp.route("/")
@login_required
def index():
    rng = _range()
    report = build_report(get_db(), g.user["id"], rng.start, rng.end)
    return render_template("reports.html", rng=rng, report=report, report_types=REPORT_TYPES,
                           anchor=request.args.get("date") or date.today().isoformat(),
                           generated_on=date.today())


@bp.route("/export.csv")
@login_required
def export_csv():
    rng = _range()
    body = export_period_csv(get_db(), g.user["id"], rng.start, rng.end, g.settings["date_format"])
    name = "report-%s-to-%s.csv" % (rng.start.isoformat(), rng.end.isoformat())
    return Response(body, mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="%s"' % name})
