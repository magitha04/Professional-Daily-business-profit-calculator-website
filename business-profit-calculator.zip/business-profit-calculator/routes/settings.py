"""Business settings, profile, password and demo data controls."""
from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for

from db import get_db
from models import expense as expense_model
from models import sale as sale_model
from models import settings as settings_model
from models import user as user_model
from services import demo_data
from services.formatting import CURRENCIES, DATE_FORMATS
from services.security import login_required
from services.validators import (BUSINESS_TYPES, check_password_strength,
                                 validate_business_settings, validate_profile)

bp = Blueprint("settings", __name__, url_prefix="/settings")


def _render(business_values=None, business_errors=None, profile_values=None,
            profile_errors=None, password_errors=None):
    db = get_db()
    return render_template(
        "settings.html",
        business_values=business_values or dict(g.settings),
        business_errors=business_errors or {},
        profile_values=profile_values or {"full_name": g.user["full_name"], "email": g.user["email"]},
        profile_errors=profile_errors or {},
        password_errors=password_errors or {},
        business_types=BUSINESS_TYPES, currencies=CURRENCIES, date_formats=list(DATE_FORMATS),
        has_demo=sale_model.has_demo(db, g.user["id"]) or expense_model.has_demo(db, g.user["id"]),
    )


@bp.route("/", methods=["GET"])
@login_required
def index():
    return _render()


@bp.route("/business", methods=["POST"])
@login_required
def save_business():
    values, errors = validate_business_settings(request.form)
    if errors:
        flash("Please fix the highlighted fields.", "danger")
        return _render(business_values=values, business_errors=errors), 400
    settings_model.update(get_db(), g.user["id"], values)
    flash("Business settings saved.", "success")
    return redirect(url_for("settings.index"))


@bp.route("/profile", methods=["POST"])
@login_required
def save_profile():
    db = get_db()
    values, errors = validate_profile(request.form)
    if not errors and user_model.exists(db, email=values["email"], exclude_id=g.user["id"]):
        errors["email"] = "Another account already uses that email."
    if errors:
        flash("Please fix the highlighted fields.", "danger")
        return _render(profile_values=values, profile_errors=errors), 400
    user_model.update_profile(db, g.user["id"], values["full_name"], values["email"])
    flash("Profile updated.", "success")
    return redirect(url_for("settings.index"))


@bp.route("/password", methods=["POST"])
@login_required
def change_password():
    current = request.form.get("current_password") or ""
    new = request.form.get("new_password") or ""
    confirm = request.form.get("confirm_password") or ""
    errors = {}
    if not user_model.verify_password(g.user, current):
        errors["current_password"] = "Your current password is incorrect."
    strength = check_password_strength(new)
    if strength:
        errors["new_password"] = strength
    elif new != confirm:
        errors["confirm_password"] = "The passwords don't match."
    if errors:
        flash("Password not changed. Please fix the highlighted fields.", "danger")
        return _render(password_errors=errors), 400
    user_model.update_password(get_db(), g.user["id"], new)
    flash("Password changed.", "success")
    return redirect(url_for("settings.index"))


@bp.route("/demo/load", methods=["POST"])
@login_required
def load_demo():
    sales, expenses = demo_data.load_demo_data(get_db(), g.user["id"])
    if sales or expenses:
        flash("Added %d demo sales and %d demo expenses." % (sales, expenses), "success")
    else:
        flash("Demo data is already loaded.", "info")
    return redirect(url_for("settings.index"))


@bp.route("/demo/clear", methods=["POST"])
@login_required
def clear_demo():
    sales, expenses = demo_data.clear_demo_data(get_db(), g.user["id"])
    flash("Removed %d demo sales and %d demo expenses. Your own entries were not touched."
          % (sales, expenses), "success")
    return redirect(url_for("settings.index"))
