"""SQLite connection handling, schema initialisation and migrations."""
import glob
import os
import sqlite3

import click
from flask import current_app, g

from config import BASE_DIR

SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")
MIGRATIONS_DIR = os.path.join(BASE_DIR, "migrations")


def connect(path):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_db():
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


def close_db(_error=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db():
    """Create all tables (safe to run repeatedly) and apply pending migrations."""
    conn = get_db()
    with open(SCHEMA_PATH, "r", encoding="utf-8") as handle:
        conn.executescript(handle.read())
    conn.execute("PRAGMA foreign_keys = ON")
    return apply_migrations(conn)


def apply_migrations(conn):
    """Apply migrations/*.sql files in filename order, once each."""
    applied = {row["version"] for row in conn.execute("SELECT version FROM schema_migrations")}
    done = []
    for path in sorted(glob.glob(os.path.join(MIGRATIONS_DIR, "*.sql"))):
        version = os.path.basename(path)
        if version in applied:
            continue
        with open(path, "r", encoding="utf-8") as handle:
            script = handle.read()
        conn.executescript(script)
        with conn:
            conn.execute("INSERT INTO schema_migrations (version) VALUES (?)", (version,))
        done.append(version)
    conn.execute("PRAGMA foreign_keys = ON")
    return done


def init_app(app):
    app.teardown_appcontext(close_db)

    with app.app_context():
        init_db()

    @app.cli.command("init-db")
    def init_db_command():
        """Create the database tables and apply pending migrations."""
        applied = init_db()
        click.echo("Database ready at %s" % current_app.config["DATABASE"])
        for name in applied:
            click.echo("Applied migration %s" % name)

    @app.cli.command("migrate")
    def migrate_command():
        """Apply new SQL files from migrations/ and list what has been applied.

        Migrations also run automatically whenever the app starts.
        """
        applied_now = init_db()
        rows = get_db().execute("SELECT version, applied_at FROM schema_migrations ORDER BY version").fetchall()
        if applied_now:
            click.echo("Applied now: %s" % ", ".join(applied_now))
        click.echo("Database is up to date. Applied migrations: %s"
                   % (", ".join(r["version"] for r in rows) if rows else "none"))

    @app.cli.command("seed-demo")
    @click.option("--username", default="demo", show_default=True)
    @click.option("--password", default=None, help="Leave empty to generate a random password.")
    def seed_demo_command(username, password):
        """Create a demo user with sample sales and expenses."""
        from services import demo_data

        message = demo_data.create_demo_user(get_db(), username, password)
        click.echo(message)

    @app.cli.command("clear-demo")
    @click.option("--username", required=True)
    @click.option("--delete-user", is_flag=True, help="Also delete the account if it is empty.")
    def clear_demo_command(username, delete_user):
        """Remove demo sales and expenses (your own entries are never touched)."""
        from services import demo_data

        click.echo(demo_data.clear_demo_for_username(get_db(), username, delete_user))
