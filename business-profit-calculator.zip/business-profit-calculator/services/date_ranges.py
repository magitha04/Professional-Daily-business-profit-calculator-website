"""Date range helpers for dashboard filters and reports."""
from collections import namedtuple
from datetime import date, timedelta

DateRange = namedtuple("DateRange", "preset start end label error")

PRESET_LABELS = {
    "today": "Today",
    "yesterday": "Yesterday",
    "7d": "Last 7 days",
    "30d": "Last 30 days",
    "custom": "Custom range",
}

EARLIEST_DATE = date(2000, 1, 1)


def parse_iso_date(text):
    """Parse YYYY-MM-DD strictly. Returns None for anything else."""
    try:
        parsed = date.fromisoformat((text or "").strip())
    except ValueError:
        return None
    return parsed if parsed >= EARLIEST_DATE else None


def resolve_range(args, today=None, max_days=366):
    """Resolve ?range=today|yesterday|7d|30d|custom&start=..&end=.. into a DateRange."""
    today = today or date.today()
    preset = (args.get("range") or "today").strip()
    if preset not in PRESET_LABELS:
        preset = "today"
    error = None

    if preset == "today":
        start = end = today
    elif preset == "yesterday":
        start = end = today - timedelta(days=1)
    elif preset == "7d":
        start, end = today - timedelta(days=6), today
    elif preset == "30d":
        start, end = today - timedelta(days=29), today
    else:
        start = parse_iso_date(args.get("start"))
        end = parse_iso_date(args.get("end"))
        if start is None or end is None:
            error = "Choose a valid start and end date."
        elif start > end:
            error = "The start date must be on or before the end date."
        elif (end - start).days + 1 > max_days:
            error = "Choose a range of %d days or fewer." % max_days
        if error:
            preset, start, end = "today", today, today

    return DateRange(preset, start, end, PRESET_LABELS[preset], error)


REPORT_TYPES = {"daily": "Daily", "weekly": "Weekly", "monthly": "Monthly", "custom": "Custom"}


def resolve_report_range(args, today=None, max_days=366):
    """Resolve report period: daily (one day), weekly (Mon-Sun), monthly (calendar month), custom."""
    today = today or date.today()
    kind = (args.get("type") or "daily").strip()
    if kind not in REPORT_TYPES:
        kind = "daily"
    anchor = parse_iso_date(args.get("date")) or today
    error = None

    if kind == "daily":
        start = end = anchor
    elif kind == "weekly":
        start = anchor - timedelta(days=anchor.weekday())
        end = start + timedelta(days=6)
    elif kind == "monthly":
        start = anchor.replace(day=1)
        next_month = (start.replace(day=28) + timedelta(days=4)).replace(day=1)
        end = next_month - timedelta(days=1)
    else:
        start = parse_iso_date(args.get("start"))
        end = parse_iso_date(args.get("end"))
        if start is None or end is None:
            error = "Choose a valid start and end date."
        elif start > end:
            error = "The start date must be on or before the end date."
        elif (end - start).days + 1 > max_days:
            error = "Choose a range of %d days or fewer." % max_days
        if error:
            kind, start, end = "daily", anchor, anchor

    return DateRange(kind, start, end, REPORT_TYPES[kind], error)
