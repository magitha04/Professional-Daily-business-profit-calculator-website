"""Optional demo data. Demo rows are flagged so they can be removed without touching real entries."""
import random
import secrets
from datetime import date, timedelta

from models import expense as expense_model
from models import sale as sale_model
from models import user as user_model

PRODUCTS = [
    # name, selling price, cost price (in minor units), typical quantity range
    ("Basmati Rice 5kg", 62000, 51000, (1, 4)),
    ("Sunflower Oil 1L", 15500, 13200, (1, 6)),
    ("Tea Powder 500g", 21000, 15500, (1, 5)),
    ("Notebook A4", 6000, 3500, (2, 12)),
    ("Mobile Recharge Voucher", 20000, 19200, (1, 3)),
    ("Packaged Snacks", 2000, 1300, (5, 25)),
    ("Soft Drink 1L", 4500, 3400, (2, 10)),
]
CUSTOMERS = ["", "", "Ravi", "Meena", "Arjun", "Fatima", "Walk-in"]
METHODS = ["Cash", "UPI", "Card", "Bank Transfer"]
METHOD_WEIGHTS = [4, 5, 2, 1]


def load_demo_data(db, user_id, days=45, today=None):
    """Add about six weeks of sample data. Returns (sales_added, expenses_added)."""
    if sale_model.has_demo(db, user_id) or expense_model.has_demo(db, user_id):
        return 0, 0
    today = today or date.today()
    rng = random.Random(2026)
    sales_added = expenses_added = 0

    for offset in range(days - 1, -1, -1):
        day = today - timedelta(days=offset)
        for _ in range(rng.randint(2, 5)):
            name, price, cost, (low, high) = rng.choice(PRODUCTS)
            quantity = rng.randint(low, high)
            gross = quantity * price
            discount = rng.choice([0, 0, 0, gross // 20]) if gross >= 1000 else 0
            sale_model.create(db, user_id, {
                "sale_date": day.isoformat(),
                "product_name": name,
                "quantity_milli": quantity * 1000,
                "selling_price_minor": price,
                "cost_price_minor": cost,
                "discount_minor": discount,
                "payment_method": rng.choices(METHODS, METHOD_WEIGHTS)[0],
                "customer_name": rng.choice(CUSTOMERS),
                "notes": "",
            }, is_demo=True)
            sales_added += 1

        def add_expense(category, description, amount, method="Cash"):
            expense_model.create(db, user_id, {
                "expense_date": day.isoformat(), "category": category,
                "description": description, "amount_minor": amount,
                "payment_method": method, "notes": "",
            }, is_demo=True)

        if day.day == 1:
            add_expense("Rent", "Shop rent", 1500000, "Bank Transfer")
            add_expense("Salary", "Helper salary", 1200000, "Bank Transfer")
            expenses_added += 2
        if day.day == 5:
            add_expense("Electricity", "Electricity bill", rng.randint(240000, 320000), "UPI")
            expenses_added += 1
        if day.weekday() in (1, 4):
            add_expense("Transport", "Stock delivery", rng.randint(30000, 60000))
            expenses_added += 1
        if day.weekday() == 3:
            add_expense("Packaging", "Bags and wrapping", rng.randint(15000, 30000))
            expenses_added += 1
        if day.weekday() == 5:
            add_expense("Marketing", "Flyers and local ads", rng.randint(20000, 50000), "UPI")
            expenses_added += 1
        if offset == days // 2:
            add_expense("Maintenance", "Fridge repair", 450000, "Card")
            expenses_added += 1
        if rng.random() < 0.3:
            add_expense("Miscellaneous", "Cleaning supplies", rng.randint(5000, 15000))
            expenses_added += 1
    return sales_added, expenses_added


def clear_demo_data(db, user_id):
    """Delete only rows flagged as demo for this user. Returns (sales_deleted, expenses_deleted)."""
    with db:
        sales = db.execute("DELETE FROM sales WHERE user_id = ? AND is_demo = 1", (user_id,)).rowcount
        expenses = db.execute("DELETE FROM expenses WHERE user_id = ? AND is_demo = 1", (user_id,)).rowcount
    return sales, expenses


def create_demo_user(db, username, password=None):
    if user_model.get_by_username(db, username):
        user = user_model.get_by_username(db, username)
        added = load_demo_data(db, user["id"])
        return "User '%s' already exists. Added %d demo sales and %d demo expenses." % ((username,) + added)
    generated = password is None
    password = password or "Demo-" + secrets.token_hex(4) + "7"
    user_id = user_model.create_user(db, username, "%s@example.com" % username, "Demo Owner", password)
    sales, expenses = load_demo_data(db, user_id)
    message = "Created demo user '%s' with %d sales and %d expenses." % (username, sales, expenses)
    if generated:
        message += "\nPassword: %s" % password
    return message


def clear_demo_for_username(db, username, delete_user=False):
    user = user_model.get_by_username(db, username)
    if user is None:
        return "No user named '%s'." % username
    sales, expenses = clear_demo_data(db, user["id"])
    message = "Removed %d demo sales and %d demo expenses for '%s'." % (sales, expenses, username)
    if delete_user:
        remaining = db.execute(
            "SELECT (SELECT COUNT(*) FROM sales WHERE user_id = ?) + "
            "(SELECT COUNT(*) FROM expenses WHERE user_id = ?)", (user["id"], user["id"])
        ).fetchone()[0]
        if remaining:
            message += " The account still has %d of its own records, so it was not deleted." % remaining
        else:
            user_model.delete_user(db, user["id"])
            message += " The empty account was deleted."
    return message
