"""Single source of truth for every profit and loss formula.

    Gross Sales  = Quantity x Selling Price
    Net Sales    = Gross Sales - Discount
    COGS         = Quantity x Cost Price
    Gross Profit = Net Sales - COGS
    Net Profit   = Gross Profit - Total Expenses
    Margin %     = Net Profit / Net Sales x 100   (only when Net Sales > 0)

The dashboard, charts, transaction history and reports all call these
functions, so their totals always agree. COGS is subtracted once (inside
Gross Profit) and expenses are subtracted once (inside Net Profit).
"""
from decimal import Decimal, ROUND_HALF_UP

from . import money


def compute_sale_amounts(quantity_milli, selling_price_minor, cost_price_minor, discount_minor=0):
    """Return every derived amount for one sale line, in minor units."""
    if quantity_milli <= 0:
        raise ValueError("Quantity must be greater than zero.")
    if min(selling_price_minor, cost_price_minor, discount_minor) < 0:
        raise ValueError("Amounts can't be negative.")
    gross_sales = money.scale(quantity_milli, selling_price_minor)
    if discount_minor > gross_sales:
        raise ValueError("Discount can't be more than the gross sales amount.")
    net_sales = gross_sales - discount_minor
    cogs = money.scale(quantity_milli, cost_price_minor)
    return {
        "gross_sales_minor": gross_sales,
        "net_sales_minor": net_sales,
        "cogs_minor": cogs,
        "gross_profit_minor": net_sales - cogs,
    }


def calculate_margin(net_profit_minor, net_sales_minor):
    """Profit margin as a Decimal percentage (2 places), or None when Net Sales <= 0."""
    if net_sales_minor <= 0:
        return None
    pct = Decimal(net_profit_minor) * 100 / Decimal(net_sales_minor)
    return pct.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def calculate_summary(sales_totals, expense_total_minor, expense_count=0):
    """Combine sales totals and the expense total into one summary dictionary.

    sales_totals needs: count, gross_sales, discounts, net_sales, cogs, gross_profit
    (all integers in minor units).
    """
    gross_profit = sales_totals["gross_profit"]
    net_profit = gross_profit - expense_total_minor
    margin = calculate_margin(net_profit, sales_totals["net_sales"])
    return {
        "sales_count": sales_totals["count"],
        "expense_count": expense_count,
        "transactions": sales_totals["count"] + expense_count,
        "gross_sales": sales_totals["gross_sales"],
        "discounts": sales_totals["discounts"],
        "net_sales": sales_totals["net_sales"],
        "cogs": sales_totals["cogs"],
        "gross_profit": gross_profit,
        "total_expenses": expense_total_minor,
        "net_profit": net_profit,
        "margin": margin,
        "is_loss": net_profit < 0,
        "expenses_exceed_gross_profit": expense_total_minor > 0 and expense_total_minor > gross_profit,
    }


def build_period_summary(db, user_id, start, end):
    """Summary for one user between two dates (inclusive). Used everywhere."""
    from models import expense as expense_model
    from models import sale as sale_model

    sales_totals = sale_model.totals(db, user_id, start, end)
    expense_totals = expense_model.totals(db, user_id, start, end)
    return calculate_summary(sales_totals, expense_totals["total"], expense_totals["count"])
