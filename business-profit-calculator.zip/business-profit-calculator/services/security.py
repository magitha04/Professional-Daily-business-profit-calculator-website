"""CSRF protection, one-time form tokens, login throttling and login_required."""
import functools
import hmac
import secrets
import time
from collections import defaultdict, deque

from flask import abort, current_app, g, jsonify, redirect, request, session, url_for


def csrf_token():
    token = session.get("_csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["_csrf_token"] = token
    return token


def issue_form_nonce():
    """One-time token for create forms so a double click or a refresh can't save twice."""
    nonce = secrets.token_urlsafe(16)
    nonces = list(session.get("_form_nonces", []))
    nonces.append(nonce)
    session["_form_nonces"] = nonces[-20:]
    return nonce


def consume_form_nonce(nonce):
    nonces = list(session.get("_form_nonces", []))
    if nonce and nonce in nonces:
        nonces.remove(nonce)
        session["_form_nonces"] = nonces
        return True
    return False


def safe_next(target):
    """Only allow same-site relative redirects."""
    if target and target.startswith("/") and not target.startswith("//") and "\\" not in target:
        return target
    return None


def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if g.get("user") is None:
            if request.path.startswith("/dashboard/data"):
                return jsonify(error="Please sign in again."), 401
            if request.method == "GET":
                target = request.full_path.rstrip("?")
                return redirect(url_for("auth.login", next=target))
            return redirect(url_for("auth.login"))
        return view(*args, **kwargs)

    return wrapped


class LoginThrottle:
    """Small in-memory limiter for failed logins (per client address and login name)."""

    def __init__(self, max_attempts, window_seconds):
        self.max_attempts = max_attempts
        self.window = window_seconds
        self.failures = defaultdict(deque)

    def _key(self, login):
        return (request.remote_addr or "unknown", (login or "").lower())

    def _prune(self, key):
        queue = self.failures[key]
        cutoff = time.time() - self.window
        while queue and queue[0] < cutoff:
            queue.popleft()
        return queue

    def blocked(self, login):
        return len(self._prune(self._key(login))) >= self.max_attempts

    def record_failure(self, login):
        self.failures[self._key(login)].append(time.time())

    def reset(self, login):
        self.failures.pop(self._key(login), None)


def init_security(app):
    app.jinja_env.globals["csrf_token"] = csrf_token
    app.jinja_env.globals["form_nonce"] = issue_form_nonce
    app.extensions["login_throttle"] = LoginThrottle(
        app.config["LOGIN_MAX_ATTEMPTS"], app.config["LOGIN_WINDOW_SECONDS"]
    )

    @app.before_request
    def protect_from_csrf():
        if not current_app.config["CSRF_ENABLED"]:
            return None
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            sent = request.form.get("csrf_token") or request.headers.get("X-CSRFToken") or ""
            expected = session.get("_csrf_token") or ""
            if not expected or not hmac.compare_digest(sent, expected):
                abort(400)
        return None

    @app.after_request
    def set_security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; "
            "script-src 'self' https://cdn.jsdelivr.net; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; "
            "font-src 'self' https://cdn.jsdelivr.net https://fonts.gstatic.com; "
            "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; form-action 'self'",
        )
        if request.endpoint != "static":
            response.headers.setdefault("Cache-Control", "no-store")
        return response
