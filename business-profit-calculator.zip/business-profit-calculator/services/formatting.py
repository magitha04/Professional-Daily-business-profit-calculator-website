"""Currency, date and quantity formatting plus Jinja filters."""
from datetime import date, datetime

from flask import g

CURRENCIES = {
    "INR": ("\u20b9", "Indian Rupee (INR)"),
    "USD": ("$", "US Dollar (USD)"),
    "EUR": ("\u20ac", "Euro (EUR)"),
    "GBP": ("\u00a3", "British Pound (GBP)"),
    "AUD": ("A$", "Australian Dollar (AUD)"),
    "CAD": ("C$", "Canadian Dollar (CAD)"),
    "AED": ("AED ", "UAE Dirham (AED)"),
}

DATE_FORMATS = {
    "DD/MM/YYYY": "%d/%m/%Y",
    "MM/DD/YYYY": "%m/%d/%Y",
    "YYYY-MM-DD": "%Y-%m-%d",
    "DD MMM YYYY": "%d %b %Y",
}


def group_digits(digits, indian=False):
    """1234567 -> '12,34,567' (Indian) or '1,234,567'."""
    if len(digits) <= 3:
        return digits
    if indian:
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        return ",".join(parts + [tail])
    parts = []
    while len(digits) > 3:
        parts.insert(0, digits[-3:])
        digits = digits[:-3]
    parts.insert(0, digits)
    return ",".join(parts)


def symbol_for(currency):
    return CURRENCIES.get(currency, CURRENCIES["INR"])[0]


def format_money(minor, currency="INR"):
    """Format integer minor units with the currency symbol and exactly 2 decimals."""
    minor = int(minor or 0)
    sign = "-" if minor < 0 else ""
    whole, fraction = divmod(abs(minor), 100)
    grouped = group_digits(str(whole), indian=(currency == "INR"))
    return "%s%s%s.%02d" % (sign, symbol_for(currency), grouped, fraction)


def plain_amount(minor):
    """Plain 2-decimal text for form fields and CSV files: 124950 -> '1249.50'."""
    minor = int(minor or 0)
    sign = "-" if minor < 0 else ""
    whole, fraction = divmod(abs(minor), 100)
    return "%s%d.%02d" % (sign, whole, fraction)


def format_quantity(milli):
    whole, fraction = divmod(int(milli), 1000)
    if fraction == 0:
        return str(whole)
    return ("%d.%03d" % (whole, fraction)).rstrip("0")


def format_date(value, fmt_key="DD/MM/YYYY"):
    if isinstance(value, str):
        try:
            value = date.fromisoformat(value[:10])
        except ValueError:
            return value
    elif isinstance(value, datetime):
        value = value.date()
    return value.strftime(DATE_FORMATS.get(fmt_key, DATE_FORMATS["DD/MM/YYYY"]))


def _currency():
    settings = g.get("settings")
    return settings["currency"] if settings else "INR"


def _date_format():
    settings = g.get("settings")
    return settings["date_format"] if settings else "DD/MM/YYYY"


def init_app(app):
    app.jinja_env.filters["money"] = lambda minor: format_money(minor, _currency())
    app.jinja_env.filters["plain"] = plain_amount
    app.jinja_env.filters["qty"] = format_quantity
    app.jinja_env.filters["fdate"] = lambda value: format_date(value, _date_format())
    app.jinja_env.filters["pct"] = lambda value: "N/A" if value is None else "%.2f%%" % value
    app.jinja_env.filters["datetime_short"] = lambda value: (value or "")[:16]
