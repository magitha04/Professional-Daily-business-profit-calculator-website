"""Report assembly (uses the same calculator as the dashboard) and CSV export."""
import csv
import io

from models import expense as expense_model
from models import sale as sale_model
from models import transaction as transaction_model

from .analytics import daily_breakdown
from .formatting import format_date, format_quantity, plain_amount
from .profit_calculator import build_period_summary

CSV_HEADERS = [
    "Date", "Type", "Product / Description", "Customer / Category", "Quantity",
    "Net Amount", "Discount", "Cost of Goods Sold", "Profit Impact",
    "Payment Method", "Notes",
]
_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def build_report(db, user_id, start, end):
    return {
        "summary": build_period_summary(db, user_id, start, end),
        "daily": daily_breakdown(db, user_id, start, end),
        "categories": expense_model.by_category(db, user_id, start, end),
        "products": sale_model.top_products(db, user_id, start, end, limit=10),
    }


def _safe_text(value):
    """Stop spreadsheet programs from running user text that starts with = + - or @."""
    text = value or ""
    if text.startswith(_FORMULA_PREFIXES):
        return "'" + text
    return text


def transactions_to_csv(rows, date_format="YYYY-MM-DD"):
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(CSV_HEADERS)
    for row in rows:
        is_sale = row["type"] == "sale"
        writer.writerow([
            format_date(row["txn_date"], date_format),
            "Sale" if is_sale else "Expense",
            _safe_text(row["title"]),
            _safe_text(row["detail"]),
            format_quantity(row["quantity_milli"]) if is_sale else "",
            plain_amount(row["amount_minor"]),
            plain_amount(row["discount_minor"]),
            plain_amount(row["cogs_minor"]),
            plain_amount(row["profit_minor"]),
            row["payment_method"],
            _safe_text(row["notes"]),
        ])
    return "\ufeff" + buffer.getvalue()


def export_period_csv(db, user_id, start, end, date_format):
    rows = transaction_model.list_all(
        db, user_id, start=start.isoformat(), end=end.isoformat(), sort="date", direction="asc"
    )
    return transactions_to_csv(rows, date_format)
