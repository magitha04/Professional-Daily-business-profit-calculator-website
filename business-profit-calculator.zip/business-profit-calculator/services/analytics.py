"""Chart data and report breakdowns, built from the same queries as the summaries."""
from datetime import timedelta

from models import expense as expense_model
from models import sale as sale_model

from .formatting import format_date, format_quantity, symbol_for


def _days(start, end):
    return [start + timedelta(days=n) for n in range((end - start).days + 1)]


def _month_keys(start, end):
    keys, year, month = [], start.year, start.month
    while (year, month) <= (end.year, end.month):
        keys.append("%04d-%02d" % (year, month))
        month += 1
        if month == 13:
            year, month = year + 1, 1
    return keys


def _major(minor):
    """Minor units to a number for Chart.js display only. Never used for calculations."""
    return round((minor or 0) / 100, 2)


def daily_breakdown(db, user_id, start, end):
    """One row per calendar day with sales, costs, expenses and profit (minor units)."""
    sales = sale_model.daily(db, user_id, start, end)
    expenses = expense_model.daily(db, user_id, start, end)
    rows = []
    for day in _days(start, end):
        key = day.isoformat()
        sale_row = sales.get(key, {})
        net_sales = sale_row.get("net_sales", 0)
        cogs = sale_row.get("cogs", 0)
        gross_profit = sale_row.get("gross_profit", 0)
        expense_total = expenses.get(key, 0)
        rows.append({
            "date": key,
            "sales_count": sale_row.get("count", 0),
            "net_sales": net_sales,
            "cogs": cogs,
            "gross_profit": gross_profit,
            "expenses": expense_total,
            "net_profit": gross_profit - expense_total,
        })
    return rows


def build_chart_data(db, user_id, start, end, currency="INR", date_format="DD/MM/YYYY"):
    rows = daily_breakdown(db, user_id, start, end)
    labels = [format_date(row["date"], date_format) for row in rows]

    sales_m = sale_model.monthly(db, user_id, start, end)
    expense_m = expense_model.monthly(db, user_id, start, end)
    month_keys = _month_keys(start, end)
    month_labels = [format_date(key + "-01", "DD MMM YYYY")[3:] for key in month_keys]
    month_profit = [
        _major(sales_m.get(key, {}).get("gross_profit", 0) - expense_m.get(key, 0))
        for key in month_keys
    ]

    categories = expense_model.by_category(db, user_id, start, end)
    products = sale_model.top_products(db, user_id, start, end, limit=5)

    has_data = any(r["sales_count"] or r["expenses"] for r in rows)
    return {
        "has_data": has_data,
        "currency_symbol": symbol_for(currency).strip(),
        "locale": "en-IN" if currency == "INR" else "en-US",
        "daily": {
            "labels": labels,
            "net_profit": [_major(r["net_profit"]) for r in rows],
            "sales": [_major(r["net_sales"]) for r in rows],
            "expenses": [_major(r["expenses"]) for r in rows],
        },
        "monthly": {"labels": month_labels, "net_profit": month_profit},
        "categories": {
            "labels": [c["category"] for c in categories],
            "values": [_major(c["total"]) for c in categories],
        },
        "products": {
            "labels": [p["product"] for p in products],
            "quantities": [float(format_quantity(p["quantity_milli"])) for p in products],
            "sales": [_major(p["net_sales"]) for p in products],
        },
    }
