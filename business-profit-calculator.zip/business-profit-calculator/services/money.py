"""Exact money and quantity handling.

Money is stored as integer minor units (paise/cents). Quantities are stored in
thousandths. Decimal is used for every conversion so no float rounding occurs.
"""
import re
from decimal import Decimal, ROUND_HALF_UP

MONEY_RE = re.compile(r"^\d{1,10}(\.\d{1,2})?$")
QTY_RE = re.compile(r"^\d{1,7}(\.\d{1,3})?$")


class MoneyError(ValueError):
    """Raised with a user-friendly message when an amount is invalid."""


def parse_money(raw):
    """Convert text like '1,249.50' to integer minor units (124950)."""
    text = (raw or "").strip().replace(",", "")
    if not text:
        raise MoneyError("Enter an amount.")
    if text.startswith("-"):
        raise MoneyError("Amount can't be negative.")
    if not MONEY_RE.match(text):
        raise MoneyError("Enter a valid amount with up to 2 decimal places, for example 249.50.")
    return int((Decimal(text) * 100).to_integral_value(ROUND_HALF_UP))


def parse_quantity(raw):
    """Convert text like '2.5' to thousandths (2500). Must be greater than zero."""
    text = (raw or "").strip().replace(",", "")
    if not text:
        raise MoneyError("Enter a quantity.")
    if text.startswith("-"):
        raise MoneyError("Quantity can't be negative.")
    if not QTY_RE.match(text):
        raise MoneyError("Enter a valid quantity with up to 3 decimal places, for example 2 or 1.5.")
    milli = int((Decimal(text) * 1000).to_integral_value(ROUND_HALF_UP))
    if milli <= 0:
        raise MoneyError("Quantity must be greater than zero.")
    return milli


def scale(quantity_milli, unit_minor):
    """quantity x unit price, rounded half-up to whole minor units."""
    exact = Decimal(quantity_milli) * Decimal(unit_minor) / Decimal(1000)
    return int(exact.to_integral_value(ROUND_HALF_UP))
