"""Server-side validation and sanitising of every form the app accepts."""
import re
from datetime import date

from . import money
from .date_ranges import EARLIEST_DATE, parse_iso_date
from .formatting import CURRENCIES, DATE_FORMATS

PAYMENT_METHODS = ["Cash", "UPI", "Card", "Bank Transfer"]
EXPENSE_CATEGORIES = [
    "Rent", "Electricity", "Salary", "Transport", "Packaging",
    "Marketing", "Maintenance", "Miscellaneous",
]
BUSINESS_TYPES = [
    "Retail Shop", "Wholesale", "Restaurant or Cafe", "Online Store",
    "Freelancer", "Service Business", "Manufacturing", "Other",
]

CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def clean_text(value, max_length, multiline=False):
    """Strip control characters and surrounding whitespace, collapse spaces."""
    text = CONTROL_CHARS.sub("", value or "").replace("\r\n", "\n").replace("\r", "\n")
    if multiline:
        text = "\n".join(re.sub(r"[ \t]+", " ", line).strip() for line in text.split("\n")).strip()
    else:
        text = re.sub(r"\s+", " ", text).strip()
    return text[:max_length] if len(text) > max_length else text


def _too_long(value, limit):
    return len(CONTROL_CHARS.sub("", value or "").strip()) > limit


def _read_date(raw, today, label):
    parsed = parse_iso_date(raw)
    if parsed is None:
        raise ValueError("Enter a valid %s." % label)
    if parsed > today:
        raise ValueError("The %s can't be in the future." % label)
    return parsed


def validate_sale(form, today=None):
    """Return (clean, values, errors). `clean` holds typed values; `values` the raw text."""
    today = today or date.today()
    fields = ["sale_date", "product_name", "quantity", "selling_price", "cost_price",
              "discount", "payment_method", "customer_name", "notes"]
    values = {name: (form.get(name) or "").strip() for name in fields}
    if not values["discount"]:
        values["discount"] = "0"
    errors, clean = {}, {}

    try:
        clean["sale_date"] = _read_date(values["sale_date"], today, "transaction date").isoformat()
    except ValueError as exc:
        errors["sale_date"] = str(exc)

    product = clean_text(values["product_name"], 120)
    if not product:
        errors["product_name"] = "Enter the product or service name."
    elif _too_long(values["product_name"], 120):
        errors["product_name"] = "Keep the name to 120 characters or fewer."
    clean["product_name"] = product

    parsers = {
        "quantity": ("quantity_milli", money.parse_quantity),
        "selling_price": ("selling_price_minor", money.parse_money),
        "cost_price": ("cost_price_minor", money.parse_money),
        "discount": ("discount_minor", money.parse_money),
    }
    for field, (target, parser) in parsers.items():
        try:
            clean[target] = parser(values[field])
        except money.MoneyError as exc:
            errors[field] = str(exc)

    if values["payment_method"] not in PAYMENT_METHODS:
        errors["payment_method"] = "Choose a payment method."
    clean["payment_method"] = values["payment_method"]

    if _too_long(values["customer_name"], 120):
        errors["customer_name"] = "Keep the customer name to 120 characters or fewer."
    clean["customer_name"] = clean_text(values["customer_name"], 120)
    if _too_long(values["notes"], 500):
        errors["notes"] = "Keep notes to 500 characters or fewer."
    clean["notes"] = clean_text(values["notes"], 500, multiline=True)

    if not any(k in errors for k in ("quantity", "selling_price", "discount")):
        gross = money.scale(clean["quantity_milli"], clean["selling_price_minor"])
        if clean["discount_minor"] > gross:
            errors["discount"] = "Discount can't be more than the gross sales amount."
    return clean, values, errors


def validate_expense(form, today=None):
    today = today or date.today()
    fields = ["expense_date", "category", "description", "amount", "payment_method", "notes"]
    values = {name: (form.get(name) or "").strip() for name in fields}
    errors, clean = {}, {}

    try:
        clean["expense_date"] = _read_date(values["expense_date"], today, "expense date").isoformat()
    except ValueError as exc:
        errors["expense_date"] = str(exc)

    if values["category"] not in EXPENSE_CATEGORIES:
        errors["category"] = "Choose a category."
    clean["category"] = values["category"]

    description = clean_text(values["description"], 200)
    if not description:
        errors["description"] = "Enter a short description."
    elif _too_long(values["description"], 200):
        errors["description"] = "Keep the description to 200 characters or fewer."
    clean["description"] = description

    try:
        clean["amount_minor"] = money.parse_money(values["amount"])
        if clean["amount_minor"] <= 0:
            errors["amount"] = "Amount must be greater than zero."
    except money.MoneyError as exc:
        errors["amount"] = str(exc)

    if values["payment_method"] not in PAYMENT_METHODS:
        errors["payment_method"] = "Choose a payment method."
    clean["payment_method"] = values["payment_method"]

    if _too_long(values["notes"], 500):
        errors["notes"] = "Keep notes to 500 characters or fewer."
    clean["notes"] = clean_text(values["notes"], 500, multiline=True)
    return clean, values, errors


def validate_registration(form):
    values = {k: (form.get(k) or "").strip() for k in ("full_name", "username", "email")}
    password = form.get("password") or ""
    confirm = form.get("confirm_password") or ""
    errors = {}

    values["full_name"] = clean_text(values["full_name"], 80)
    if len(values["full_name"]) < 2:
        errors["full_name"] = "Enter your full name."
    if not USERNAME_RE.match(values["username"]):
        errors["username"] = "Use 3 to 30 letters, numbers, dots, dashes or underscores."
    if not EMAIL_RE.match(values["email"]) or len(values["email"]) > 120:
        errors["email"] = "Enter a valid email address."
    password_error = check_password_strength(password)
    if password_error:
        errors["password"] = password_error
    elif password != confirm:
        errors["confirm_password"] = "The passwords don't match."
    return values, password, errors


def check_password_strength(password):
    if len(password) < 8:
        return "Use at least 8 characters."
    if len(password) > 128:
        return "Use 128 characters or fewer."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "Include at least one letter and one number."
    return None


def validate_profile(form):
    values = {k: (form.get(k) or "").strip() for k in ("full_name", "email")}
    errors = {}
    values["full_name"] = clean_text(values["full_name"], 80)
    if len(values["full_name"]) < 2:
        errors["full_name"] = "Enter your full name."
    if not EMAIL_RE.match(values["email"]) or len(values["email"]) > 120:
        errors["email"] = "Enter a valid email address."
    return values, errors


def validate_business_settings(form):
    values = {k: (form.get(k) or "").strip() for k in
              ("business_name", "business_type", "currency", "address", "date_format")}
    errors = {}
    values["business_name"] = clean_text(values["business_name"], 100)
    if not values["business_name"]:
        errors["business_name"] = "Enter your business name."
    if values["business_type"] not in BUSINESS_TYPES:
        errors["business_type"] = "Choose a business type."
    if values["currency"] not in CURRENCIES:
        errors["currency"] = "Choose a currency."
    if values["date_format"] not in DATE_FORMATS:
        errors["date_format"] = "Choose a date format."
    if _too_long(values["address"], 250):
        errors["address"] = "Keep the address to 250 characters or fewer."
    values["address"] = clean_text(values["address"], 250, multiline=True)
    return values, errors


SORTS = {"date", "amount", "profit", "product", "category"}


def parse_list_filters(args, allowed_sorts):
    """Read search, date, payment, sort and page parameters safely."""
    start = parse_iso_date(args.get("start"))
    end = parse_iso_date(args.get("end"))
    sort = args.get("sort") if args.get("sort") in allowed_sorts else "date"
    try:
        page = max(1, int(args.get("page", 1)))
    except (TypeError, ValueError):
        page = 1
    payment = args.get("payment") if args.get("payment") in PAYMENT_METHODS else ""
    return {
        "q": clean_text(args.get("q", ""), 100),
        "start": start.isoformat() if start else "",
        "end": end.isoformat() if end else "",
        "payment": payment,
        "sort": sort,
        "dir": "asc" if args.get("dir") == "asc" else "desc",
        "page": min(page, 100000),
    }


def with_args(filters):
    """Add two helper keys to a filters dict.

    args:   the non-empty filter values (except page), ready for building links
    active: True when the user applied a real filter such as a search or date,
            so default sorting alone doesn't count
    """
    ignored = ("page", "args", "active", "sort", "dir")
    filters["args"] = {k: v for k, v in filters.items() if v and k not in ("page", "args", "active")}
    filters["active"] = any(v for k, v in filters.items() if k not in ignored)
    return filters
