"""Business logic: calculations, validation, formatting, reports and security helpers."""
