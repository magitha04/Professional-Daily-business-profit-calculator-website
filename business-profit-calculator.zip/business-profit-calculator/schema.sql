-- Professional Daily Business Profit Calculator: SQLite schema (version 1)
-- All money is stored as INTEGER minor units (paise / cents) to avoid
-- floating-point rounding errors. Quantities are stored in thousandths
-- (quantity_milli) so values like 1.5 kg are exact.
-- This file is idempotent: running it again does not change existing data.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
    version    TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    full_name     TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS business_settings (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    business_name TEXT NOT NULL DEFAULT 'My Business',
    business_type TEXT NOT NULL DEFAULT 'Retail Shop',
    currency      TEXT NOT NULL DEFAULT 'INR',
    address       TEXT NOT NULL DEFAULT '',
    date_format   TEXT NOT NULL DEFAULT 'DD/MM/YYYY',
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sales (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id            INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    sale_date          TEXT NOT NULL,                       -- ISO date YYYY-MM-DD
    product_name       TEXT NOT NULL,
    quantity_milli     INTEGER NOT NULL CHECK (quantity_milli > 0),
    selling_price_minor INTEGER NOT NULL CHECK (selling_price_minor >= 0),
    cost_price_minor   INTEGER NOT NULL CHECK (cost_price_minor >= 0),
    discount_minor     INTEGER NOT NULL DEFAULT 0 CHECK (discount_minor >= 0),
    gross_sales_minor  INTEGER NOT NULL CHECK (gross_sales_minor >= 0),
    net_sales_minor    INTEGER NOT NULL CHECK (net_sales_minor >= 0),
    cogs_minor         INTEGER NOT NULL CHECK (cogs_minor >= 0),
    gross_profit_minor INTEGER NOT NULL,                    -- may be negative
    payment_method     TEXT NOT NULL,
    customer_name      TEXT NOT NULL DEFAULT '',
    notes              TEXT NOT NULL DEFAULT '',
    is_demo            INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0, 1)),
    created_at         TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_sales_user_date ON sales (user_id, sale_date);

CREATE TABLE IF NOT EXISTS expenses (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expense_date   TEXT NOT NULL,
    category       TEXT NOT NULL,
    description    TEXT NOT NULL,
    amount_minor   INTEGER NOT NULL CHECK (amount_minor > 0),
    payment_method TEXT NOT NULL,
    notes          TEXT NOT NULL DEFAULT '',
    is_demo        INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0, 1)),
    created_at     TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_expenses_user_date ON expenses (user_id, expense_date);
