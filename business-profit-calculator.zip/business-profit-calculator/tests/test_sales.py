"""Sales CRUD, validation, duplicate prevention and per-user data isolation."""
import unittest
from datetime import date, timedelta

from tests.helpers import AppTestCase


class SalesTests(AppTestCase):
    def setUp(self):
        super().setUp()
        self.signup_and_login()

    def test_add_sale_computes_amounts_on_server(self):
        response = self.add_sale(quantity="3", selling_price="100", cost_price="60", discount="25")
        self.assertEqual(response.status_code, 302)
        row = self.query("SELECT * FROM sales")[0]
        self.assertEqual(row["gross_sales_minor"], 30000)
        self.assertEqual(row["net_sales_minor"], 27500)
        self.assertEqual(row["cogs_minor"], 18000)
        self.assertEqual(row["gross_profit_minor"], 9500)

    def test_browser_cannot_inject_totals(self):
        self.add_sale(gross_profit_minor="999999", net_sales_minor="1", cogs_minor="1")
        row = self.query("SELECT * FROM sales")[0]
        self.assertEqual(row["gross_profit_minor"], 12000)

    def test_validation_rejects_bad_values(self):
        bad_cases = {
            "quantity": ["0", "-2", "abc", "", "1.2345"],
            "selling_price": ["-1", "abc", "", "1.999"],
            "cost_price": ["-5", "x", ""],
            "discount": ["-1", "zzz"],
            "product_name": ["", "   "],
            "payment_method": ["Cheque", ""],
            "sale_date": ["", "2026-13-40", "not-a-date"],
        }
        for field, values in bad_cases.items():
            for value in values:
                data = self.sale_form(**{field: value})
                data["form_nonce"] = self.nonce(self.client, "/sales/add")
                response = self.post(self.client, "/sales/add", data)
                self.assertEqual(response.status_code, 200, (field, value))
                self.assertIn("is-invalid", response.get_data(as_text=True), (field, value))
        self.assertEqual(len(self.query("SELECT id FROM sales")), 0)

    def test_future_date_rejected(self):
        tomorrow = (date.today() + timedelta(days=1)).isoformat()
        response = self.add_sale(sale_date=tomorrow)
        self.assertEqual(response.status_code, 200)
        self.assertIn("can&#39;t be in the future", response.get_data(as_text=True))

    def test_discount_cannot_exceed_gross_sales(self):
        response = self.add_sale(quantity="1", selling_price="10", discount="10.01")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Discount can&#39;t be more", response.get_data(as_text=True))
        self.assertEqual(len(self.query("SELECT id FROM sales")), 0)

    def test_duplicate_submission_is_blocked(self):
        data = self.sale_form()
        data["form_nonce"] = self.nonce(self.client, "/sales/add")
        first = self.post(self.client, "/sales/add", data)
        second = self.post(self.client, "/sales/add", data)
        self.assertEqual(first.status_code, 302)
        self.assertEqual(second.status_code, 302)
        self.assertEqual(len(self.query("SELECT id FROM sales")), 1)
        page = self.client.get("/sales/").get_data(as_text=True)
        self.assertEqual(page.count('aria-label="Edit Widget"'), 1)

    def test_edit_sale_recalculates(self):
        self.add_sale()
        sale_id = self.query("SELECT id FROM sales")[0]["id"]
        page = self.client.get("/sales/%d/edit" % sale_id).get_data(as_text=True)
        self.assertIn('value="Widget"', page)
        self.assertIn('value="100.00"', page)
        response = self.post(self.client, "/sales/%d/edit" % sale_id, self.sale_form(
            product_name="Gadget", quantity="2.5", selling_price="80", cost_price="90", discount="10"))
        self.assertEqual(response.status_code, 302)
        row = self.query("SELECT * FROM sales WHERE id = ?", (sale_id,))[0]
        self.assertEqual(row["product_name"], "Gadget")
        self.assertEqual(row["quantity_milli"], 2500)
        self.assertEqual(row["gross_sales_minor"], 20000)
        self.assertEqual(row["net_sales_minor"], 19000)
        self.assertEqual(row["cogs_minor"], 22500)
        self.assertEqual(row["gross_profit_minor"], -3500)  # a loss on this sale

    def test_edit_with_invalid_data_keeps_original(self):
        self.add_sale()
        sale_id = self.query("SELECT id FROM sales")[0]["id"]
        response = self.post(self.client, "/sales/%d/edit" % sale_id, self.sale_form(quantity="-1"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.query("SELECT quantity_milli FROM sales")[0]["quantity_milli"], 3000)

    def test_delete_requires_post_and_removes_row(self):
        self.add_sale()
        sale_id = self.query("SELECT id FROM sales")[0]["id"]
        self.assertEqual(self.client.get("/sales/%d/delete" % sale_id).status_code, 405)
        self.assertEqual(len(self.query("SELECT id FROM sales")), 1)
        response = self.post(self.client, "/sales/%d/delete" % sale_id)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(len(self.query("SELECT id FROM sales")), 0)

    def test_search_filter_sort_and_pagination(self):
        for i in range(17):
            self.add_sale(product_name="Item %02d" % i, selling_price=str(10 + i))
        self.add_sale(product_name="Special_100%", payment_method="UPI")
        page1 = self.client.get("/sales/").get_data(as_text=True)
        self.assertIn("pagination", page1)
        page2 = self.client.get("/sales/?page=2").get_data(as_text=True)
        self.assertEqual(self.client.get("/sales/?page=999").status_code, 200)
        self.assertNotEqual(page1, page2)
        found = self.client.get("/sales/?q=Item+05").get_data(as_text=True)
        self.assertIn("Item 05", found)
        self.assertNotIn("Item 06", found)
        wildcard = self.client.get("/sales/?q=%25").get_data(as_text=True)  # literal percent sign
        self.assertIn("Special_100%", wildcard)
        self.assertNotIn("Item 05", wildcard)
        upi = self.client.get("/sales/?payment=UPI").get_data(as_text=True)
        self.assertIn("Special_100%", upi)
        self.assertNotIn("Item 05", upi)
        asc = self.client.get("/sales/?sort=amount&dir=asc").get_data(as_text=True)
        self.assertLess(asc.index("Item 00"), asc.index("Item 05"))
        self.assertEqual(self.client.get("/sales/?sort=evil;DROP&dir=x&page=abc").status_code, 200)
        empty = self.client.get("/sales/?q=zzzzzz").get_data(as_text=True)
        self.assertIn("No sales match these filters", empty)

    def test_empty_state(self):
        self.assertIn("No sales yet", self.client.get("/sales/").get_data(as_text=True))

    def test_html_in_inputs_is_escaped(self):
        self.add_sale(product_name="<script>alert(1)</script>")
        page = self.client.get("/sales/").get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", page)
        self.assertIn("&lt;script&gt;", page)


class IsolationTests(AppTestCase):
    def setUp(self):
        super().setUp()
        self.alice = self.signup_and_login(self.new_client(), "alice")
        self.bob = self.signup_and_login(self.new_client(), "bob")
        self.add_sale(self.alice, product_name="AliceSecretProduct")
        self.add_expense(self.alice, description="AliceSecretExpense")
        self.sale_id = self.query("SELECT id FROM sales")[0]["id"]
        self.expense_id = self.query("SELECT id FROM expenses")[0]["id"]

    def test_other_user_cannot_view_edit_or_delete(self):
        for url in ("/sales/%d/edit" % self.sale_id, "/expenses/%d/edit" % self.expense_id):
            self.assertEqual(self.bob.get(url).status_code, 404, url)
        r = self.post(self.bob, "/sales/%d/edit" % self.sale_id, self.sale_form(product_name="Hacked"))
        self.assertEqual(r.status_code, 404)
        r = self.post(self.bob, "/expenses/%d/edit" % self.expense_id, self.expense_form(description="Hacked"))
        self.assertEqual(r.status_code, 404)
        self.assertEqual(self.post(self.bob, "/sales/%d/delete" % self.sale_id).status_code, 404)
        self.assertEqual(self.post(self.bob, "/expenses/%d/delete" % self.expense_id).status_code, 404)
        self.assertEqual(self.query("SELECT product_name FROM sales")[0]["product_name"], "AliceSecretProduct")
        self.assertEqual(len(self.query("SELECT id FROM expenses")), 1)

    def test_other_user_never_sees_records_in_any_view(self):
        for url in ("/sales/", "/expenses/", "/transactions/", "/transactions/export.csv",
                    "/reports/", "/reports/export.csv", "/dashboard", "/dashboard/data"):
            text = self.bob.get(url).get_data(as_text=True)
            self.assertNotIn("AliceSecret", text, url)

    def test_other_users_totals_are_zero(self):
        summary_page = self.bob.get("/dashboard").get_data(as_text=True)
        self.assertIn("No records in this period", summary_page)
        data = self.bob.get("/dashboard/data").get_json()
        self.assertFalse(data["has_data"])
        alice_data = self.alice.get("/dashboard/data").get_json()
        self.assertTrue(alice_data["has_data"])

    def test_records_are_owned_by_the_creating_user(self):
        owners = self.query("SELECT u.username FROM sales s JOIN users u ON u.id = s.user_id")
        self.assertEqual([r["username"] for r in owners], ["alice"])

    def test_foreign_key_enforced(self):
        from db import connect
        import sqlite3
        conn = connect(self.db_path)
        with self.assertRaises(sqlite3.IntegrityError):
            conn.execute("INSERT INTO expenses (user_id, expense_date, category, description, amount_minor, payment_method) "
                         "VALUES (9999, '2026-01-01', 'Rent', 'x', 100, 'Cash')")
        conn.close()


if __name__ == "__main__":
    unittest.main()
