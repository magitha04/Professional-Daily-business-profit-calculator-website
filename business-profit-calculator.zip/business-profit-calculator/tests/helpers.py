"""Shared test helpers: temporary database, CSRF handling and common form posts."""
import os
import re
import shutil
import sys
import tempfile
import unittest
from datetime import date

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app import create_app  # noqa: E402
from db import connect  # noqa: E402


class AppTestCase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="pc-test-")
        self.db_path = os.path.join(self.tmpdir, "test.db")
        self.app = create_app({
            "TESTING": True, "DATABASE": self.db_path,
            "SECRET_KEY": "test-secret", "SECRET_KEY_GENERATED": False,
        })
        self.client = self.app.test_client()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    # --- helpers -----------------------------------------------------
    def new_client(self):
        return self.app.test_client()

    def csrf(self, client):
        with client.session_transaction() as sess:
            return sess.setdefault("_csrf_token", "test-csrf-token")

    def post(self, client, url, data=None, **kwargs):
        payload = dict(data or {})
        payload.setdefault("csrf_token", self.csrf(client))
        return client.post(url, data=payload, **kwargs)

    def nonce(self, client, url):
        html = client.get(url).get_data(as_text=True)
        match = re.search(r'name="form_nonce" value="([^"]+)"', html)
        self.assertIsNotNone(match, "form nonce missing on %s" % url)
        return match.group(1)

    def register(self, client, username="alice", password="Passw0rd!", email=None):
        return self.post(client, "/register", {
            "full_name": username.title() + " Owner", "username": username,
            "email": email or username + "@example.com",
            "password": password, "confirm_password": password,
        })

    def login(self, client, username="alice", password="Passw0rd!"):
        return self.post(client, "/login", {"login": username, "password": password})

    def signup_and_login(self, client=None, username="alice"):
        client = client or self.client
        self.register(client, username)
        response = self.login(client, username)
        self.assertEqual(response.status_code, 302)
        return client

    def sale_form(self, **overrides):
        data = {
            "sale_date": date.today().isoformat(), "product_name": "Widget",
            "quantity": "3", "selling_price": "100.00", "cost_price": "60.00",
            "discount": "0", "payment_method": "Cash", "customer_name": "", "notes": "",
        }
        data.update(overrides)
        return data

    def expense_form(self, **overrides):
        data = {
            "expense_date": date.today().isoformat(), "category": "Rent",
            "description": "Shop rent", "amount": "50.00",
            "payment_method": "Cash", "notes": "",
        }
        data.update(overrides)
        return data

    def add_sale(self, client=None, **overrides):
        client = client or self.client
        data = self.sale_form(**overrides)
        data["form_nonce"] = self.nonce(client, "/sales/add")
        return self.post(client, "/sales/add", data)

    def add_expense(self, client=None, **overrides):
        client = client or self.client
        data = self.expense_form(**overrides)
        data["form_nonce"] = self.nonce(client, "/expenses/add")
        return self.post(client, "/expenses/add", data)

    def query(self, sql, params=()):
        conn = connect(self.db_path)
        try:
            return conn.execute(sql, params).fetchall()
        finally:
            conn.close()
