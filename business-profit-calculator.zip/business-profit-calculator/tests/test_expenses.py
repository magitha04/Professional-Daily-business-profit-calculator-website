"""Expense CRUD, validation, filters and the warning banner."""
import unittest

from tests.helpers import AppTestCase


class ExpenseTests(AppTestCase):
    def setUp(self):
        super().setUp()
        self.signup_and_login()

    def test_add_edit_delete_expense(self):
        self.assertEqual(self.add_expense(amount="1,250.50").status_code, 302)
        row = self.query("SELECT * FROM expenses")[0]
        self.assertEqual(row["amount_minor"], 125050)
        eid = row["id"]
        r = self.post(self.client, "/expenses/%d/edit" % eid,
                      self.expense_form(category="Marketing", description="Flyers", amount="75"))
        self.assertEqual(r.status_code, 302)
        row = self.query("SELECT * FROM expenses WHERE id = ?", (eid,))[0]
        self.assertEqual((row["category"], row["amount_minor"]), ("Marketing", 7500))
        self.assertEqual(self.client.get("/expenses/%d/delete" % eid).status_code, 405)
        self.assertEqual(self.post(self.client, "/expenses/%d/delete" % eid).status_code, 302)
        self.assertEqual(len(self.query("SELECT id FROM expenses")), 0)

    def test_validation(self):
        for field, value in (("amount", "0"), ("amount", "-5"), ("amount", "abc"), ("amount", ""),
                             ("category", "Bribes"), ("category", ""), ("description", ""),
                             ("payment_method", "Barter"), ("expense_date", "2026-02-31")):
            response = self.add_expense(**{field: value})
            self.assertEqual(response.status_code, 200, (field, value))
            self.assertIn("is-invalid", response.get_data(as_text=True), (field, value))
        self.assertEqual(len(self.query("SELECT id FROM expenses")), 0)

    def test_all_default_categories_are_accepted(self):
        for category in ("Rent", "Electricity", "Salary", "Transport", "Packaging",
                         "Marketing", "Maintenance", "Miscellaneous"):
            self.assertEqual(self.add_expense(category=category).status_code, 302, category)
        self.assertEqual(len(self.query("SELECT id FROM expenses")), 8)

    def test_duplicate_submission_blocked(self):
        data = self.expense_form()
        data["form_nonce"] = self.nonce(self.client, "/expenses/add")
        self.post(self.client, "/expenses/add", data)
        self.post(self.client, "/expenses/add", data)
        self.assertEqual(len(self.query("SELECT id FROM expenses")), 1)

    def test_filter_and_search(self):
        self.add_expense(category="Rent", description="March rent")
        self.add_expense(category="Salary", description="Helper pay", payment_method="UPI")
        by_cat = self.client.get("/expenses/?category=Salary").get_data(as_text=True)
        self.assertIn("Helper pay", by_cat)
        self.assertNotIn("March rent", by_cat)
        by_text = self.client.get("/expenses/?q=march").get_data(as_text=True)
        self.assertIn("March rent", by_text)
        self.assertNotIn("Helper pay", by_text)
        by_pay = self.client.get("/expenses/?payment=UPI").get_data(as_text=True)
        self.assertIn("Helper pay", by_pay)
        self.assertEqual(self.client.get("/expenses/?category=Nope").status_code, 200)
        self.assertIn("No expenses yet", self.new_client_page())

    def new_client_page(self):
        other = self.signup_and_login(self.new_client(), "carol")
        return other.get("/expenses/").get_data(as_text=True)

    def test_warning_when_expenses_exceed_gross_profit(self):
        self.add_sale(quantity="1", selling_price="100", cost_price="60")  # gross profit 40
        page = self.client.get("/dashboard").get_data(as_text=True)
        self.assertNotIn("expenseWarning", page)
        self.add_expense(amount="40")  # equal: not exceeding
        self.assertNotIn("expenseWarning", self.client.get("/dashboard").get_data(as_text=True))
        self.add_expense(amount="0.01", description="One more")
        page = self.client.get("/dashboard").get_data(as_text=True)
        self.assertIn("expenseWarning", page)
        self.assertIn("running at a loss", page)


if __name__ == "__main__":
    unittest.main()
