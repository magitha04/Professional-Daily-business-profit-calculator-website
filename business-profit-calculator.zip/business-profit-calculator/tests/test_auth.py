"""Registration, login, logout, route protection and CSRF."""
import unittest

from tests.helpers import AppTestCase


class AuthTests(AppTestCase):
    def test_register_creates_user_with_hashed_password_and_settings(self):
        response = self.register(self.client)
        self.assertEqual(response.status_code, 302)
        rows = self.query("SELECT password_hash FROM users WHERE username = 'alice'")
        self.assertEqual(len(rows), 1)
        self.assertNotIn("Passw0rd!", rows[0]["password_hash"])
        self.assertTrue(rows[0]["password_hash"].startswith(("scrypt:", "pbkdf2:")))
        settings = self.query("SELECT currency FROM business_settings")
        self.assertEqual([r["currency"] for r in settings], ["INR"])

    def test_register_validation_errors(self):
        cases = [
            ({"password": "short1", "confirm_password": "short1"}, "at least 8"),
            ({"password": "onlyletters", "confirm_password": "onlyletters"}, "letter and one number"),
            ({"confirm_password": "Different1"}, "don&#39;t match"),
            ({"email": "not-an-email"}, "valid email"),
            ({"username": "a b"}, "3 to 30"),
        ]
        for overrides, expected in cases:
            data = {"full_name": "Test User", "username": "tester", "email": "t@example.com",
                    "password": "Passw0rd!", "confirm_password": "Passw0rd!"}
            data.update(overrides)
            response = self.post(self.client, "/register", data)
            self.assertEqual(response.status_code, 200, overrides)
            self.assertIn(expected, response.get_data(as_text=True), overrides)
        self.assertEqual(self.query("SELECT COUNT(*) AS n FROM users")[0]["n"], 0)

    def test_duplicate_username_and_email_rejected(self):
        self.register(self.client, "alice")
        dup_name = self.register(self.new_client(), "ALICE", email="other@example.com")
        self.assertIn("already taken", dup_name.get_data(as_text=True))
        dup_email = self.register(self.new_client(), "bob", email="alice@example.com")
        self.assertIn("already exists", dup_email.get_data(as_text=True))
        self.assertEqual(self.query("SELECT COUNT(*) AS n FROM users")[0]["n"], 1)

    def test_login_with_username_or_email(self):
        self.register(self.client)
        for login in ("alice", "alice@example.com"):
            client = self.new_client()
            response = self.login(client, login)
            self.assertEqual(response.status_code, 302)
            self.assertTrue(response.headers["Location"].endswith("/dashboard"))
            self.assertEqual(client.get("/dashboard").status_code, 200)

    def test_wrong_password_is_rejected_with_generic_message(self):
        self.register(self.client)
        response = self.login(self.new_client(), "alice", "WrongPass1")
        self.assertEqual(response.status_code, 401)
        text = response.get_data(as_text=True)
        self.assertIn("Incorrect username or password", text)
        response = self.login(self.new_client(), "nobody", "Passw0rd!")
        self.assertIn("Incorrect username or password", response.get_data(as_text=True))

    def test_logout_requires_post_and_ends_session(self):
        self.signup_and_login()
        self.assertEqual(self.client.get("/logout").status_code, 405)
        self.assertEqual(self.client.get("/dashboard").status_code, 200)
        self.assertEqual(self.post(self.client, "/logout").status_code, 302)
        self.assertEqual(self.client.get("/dashboard").status_code, 302)

    def test_unauthorized_access_redirects_to_login(self):
        for url in ("/dashboard", "/sales/", "/sales/add", "/expenses/", "/expenses/add",
                    "/transactions/", "/transactions/export.csv", "/reports/",
                    "/reports/export.csv", "/settings/"):
            response = self.client.get(url)
            self.assertEqual(response.status_code, 302, url)
            self.assertIn("/login", response.headers["Location"], url)
        self.assertEqual(self.client.get("/dashboard/data").status_code, 401)

    def test_unauthenticated_posts_do_not_change_data(self):
        for url in ("/sales/add", "/expenses/add", "/sales/1/delete", "/settings/business"):
            response = self.post(self.client, url, {})
            self.assertEqual(response.status_code, 302, url)
            self.assertIn("/login", response.headers["Location"], url)

    def test_login_redirect_blocks_open_redirects(self):
        self.register(self.client)
        for target, expected_end in (("/sales/", "/sales/"), ("//evil.example.com", "/dashboard"),
                                     ("https://evil.example.com", "/dashboard")):
            client = self.new_client()
            response = self.post(client, "/login", {"login": "alice", "password": "Passw0rd!", "next": target})
            self.assertEqual(response.status_code, 302)
            self.assertTrue(response.headers["Location"].endswith(expected_end), target)
            self.assertNotIn("evil", response.headers["Location"])

    def test_authenticated_user_is_redirected_away_from_login(self):
        self.signup_and_login()
        self.assertEqual(self.client.get("/login").status_code, 302)

    def test_csrf_token_required_on_post(self):
        self.register(self.client)
        response = self.client.post("/login", data={"login": "alice", "password": "Passw0rd!"})
        self.assertEqual(response.status_code, 400)
        client = self.new_client()
        client.get("/login")
        response = client.post("/login", data={"login": "alice", "password": "Passw0rd!", "csrf_token": "forged"})
        self.assertEqual(response.status_code, 400)

    def test_failed_login_throttle(self):
        self.register(self.client)
        client = self.new_client()
        for _ in range(5):
            self.assertEqual(self.login(client, "alice", "WrongPass1").status_code, 401)
        self.assertEqual(self.login(client, "alice", "Passw0rd!").status_code, 429)

    def test_security_headers_present(self):
        response = self.client.get("/login")
        self.assertEqual(response.headers["X-Frame-Options"], "DENY")
        self.assertIn("default-src 'self'", response.headers["Content-Security-Policy"])
        self.assertEqual(response.headers["X-Content-Type-Options"], "nosniff")

    def test_session_cookie_flags(self):
        self.register(self.client)
        response = self.login(self.new_client())
        cookie = response.headers.get("Set-Cookie", "")
        self.assertIn("HttpOnly", cookie)
        self.assertIn("SameSite=Lax", cookie)

    def test_sql_injection_in_login_does_not_authenticate(self):
        self.register(self.client)
        response = self.login(self.new_client(), "alice' OR '1'='1", "x' OR '1'='1")
        self.assertEqual(response.status_code, 401)

    def test_404_page(self):
        self.signup_and_login()
        response = self.client.get("/nope")
        self.assertEqual(response.status_code, 404)
        self.assertIn("find that page", response.get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
