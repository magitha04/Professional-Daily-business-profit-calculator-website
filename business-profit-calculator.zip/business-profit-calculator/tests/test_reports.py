"""Dashboard, transactions, reports and CSV exports must agree with each other."""
import csv
import io
import re
import unittest
from datetime import date, timedelta

from tests.helpers import AppTestCase


def card_value(html, card_id):
    match = re.search(r'id="%s".*?class="(?:stat-value|stat-hero-value)[^"]*">([^<]+)<' % card_id, html, re.S)
    return match.group(1).strip() if match else None


class ReportTests(AppTestCase):
    def setUp(self):
        super().setUp()
        self.signup_and_login()
        self.today = date.today()
        self.add_sale(product_name="Tea", quantity="3", selling_price="100", cost_price="60", discount="25")
        self.add_sale(product_name="Tea", quantity="2", selling_price="100", cost_price="60")
        self.add_sale(product_name="Cake", quantity="1", selling_price="50", cost_price="55", payment_method="UPI")
        self.add_expense(amount="40", category="Rent")
        self.add_expense(amount="10.50", category="Transport", description="Auto")
        # Net sales 275 + 200 + 50 = 525; COGS 180 + 120 + 55 = 355; GP 170
        # Expenses 50.50 -> net profit 119.50; margin 119.50/525 = 22.76%

    def test_dashboard_cards_show_correct_numbers(self):
        html = self.client.get("/dashboard?range=today").get_data(as_text=True)
        self.assertEqual(card_value(html, "cardSales"), "\u20b9525.00")
        self.assertEqual(card_value(html, "cardCogs"), "\u20b9355.00")
        self.assertEqual(card_value(html, "cardExpenses"), "\u20b950.50")
        self.assertEqual(card_value(html, "cardGrossProfit"), "\u20b9170.00")
        self.assertEqual(card_value(html, "cardNetProfit"), "\u20b9119.50")
        self.assertEqual(card_value(html, "cardMargin"), "22.76%")
        self.assertEqual(card_value(html, "cardTransactions"), "5")
        self.assertIn("Tea", html)  # best seller

    def test_report_matches_dashboard(self):
        dash = self.client.get("/dashboard?range=today").get_data(as_text=True)
        report = self.client.get("/reports/?type=daily&date=%s" % self.today.isoformat()).get_data(as_text=True)
        summary_html = report[report.index('id="reportSummary"'):]
        for label, card in (("Net sales", "cardSales"), ("Cost of goods sold", "cardCogs"),
                            ("Gross profit", "cardGrossProfit"), ("Total expenses", "cardExpenses"),
                            ("Net profit", "cardNetProfit"), ("Profit margin", "cardMargin")):
            value = card_value(dash, card)
            row = re.search(r"<th[^>]*>%s</th><td[^>]*>([^<]+)</td>" % label, summary_html)
            self.assertIsNotNone(row, label)
            self.assertEqual(row.group(1).strip(), value, label)

    def test_weekly_and_monthly_reports_include_today(self):
        for kind in ("weekly", "monthly"):
            html = self.client.get("/reports/?type=%s&date=%s" % (kind, self.today.isoformat())).get_data(as_text=True)
            self.assertIn("\u20b9119.50", html, kind)
            self.assertIn("Day by day", html, kind)

    def test_custom_report_and_invalid_range(self):
        start = (self.today - timedelta(days=3)).isoformat()
        html = self.client.get("/reports/?type=custom&start=%s&end=%s" % (start, self.today.isoformat())).get_data(as_text=True)
        self.assertIn("\u20b9119.50", html)
        bad = self.client.get("/reports/?type=custom&start=%s&end=%s" % (self.today.isoformat(), start)).get_data(as_text=True)
        self.assertIn("start date must be on or before", bad)

    def test_dashboard_filters(self):
        yesterday = self.client.get("/dashboard?range=yesterday").get_data(as_text=True)
        self.assertEqual(card_value(yesterday, "cardSales"), "\u20b90.00")
        self.assertEqual(card_value(yesterday, "cardMargin"), "N/A")
        self.assertIn("No records in this period", yesterday)
        week = self.client.get("/dashboard?range=7d").get_data(as_text=True)
        self.assertEqual(card_value(week, "cardNetProfit"), "\u20b9119.50")
        custom = self.client.get("/dashboard?range=custom&start=%s&end=%s" % (self.today.isoformat(), self.today.isoformat()))
        self.assertEqual(card_value(custom.get_data(as_text=True), "cardSales"), "\u20b9525.00")
        broken = self.client.get("/dashboard?range=custom&start=bad&end=bad").get_data(as_text=True)
        self.assertIn("Choose a valid start and end date", broken)

    def test_zero_sales_loss_is_displayed_without_errors(self):
        other = self.signup_and_login(self.new_client(), "dave")
        self.add_expense(other, amount="75")
        html = other.get("/dashboard").get_data(as_text=True)
        self.assertIn("Net loss", html)
        self.assertEqual(card_value(html, "cardNetProfit"), "-\u20b975.00")
        self.assertEqual(card_value(html, "cardMargin"), "N/A")

    def test_chart_data_uses_real_totals_and_filters(self):
        data = self.client.get("/dashboard/data?range=today").get_json()
        self.assertTrue(data["has_data"])
        self.assertEqual(data["daily"]["net_profit"], [119.5])
        self.assertEqual(data["daily"]["sales"], [525.0])
        self.assertEqual(data["daily"]["expenses"], [50.5])
        self.assertEqual(dict(zip(data["categories"]["labels"], data["categories"]["values"])),
                         {"Rent": 40.0, "Transport": 10.5})
        self.assertEqual(data["products"]["labels"][0], "Tea")
        self.assertEqual(data["products"]["quantities"][0], 5.0)
        self.assertEqual(data["monthly"]["net_profit"], [119.5])
        week = self.client.get("/dashboard/data?range=7d").get_json()
        self.assertEqual(len(week["daily"]["labels"]), 7)
        self.assertEqual(week["daily"]["net_profit"][-1], 119.5)
        self.assertEqual(sum(week["daily"]["net_profit"][:-1]), 0)
        yesterday = self.client.get("/dashboard/data?range=yesterday").get_json()
        self.assertFalse(yesterday["has_data"])
        self.assertEqual(yesterday["categories"]["labels"], [])

    def test_transactions_page_and_filters(self):
        html = self.client.get("/transactions/").get_data(as_text=True)
        self.assertEqual(html.count('class="badge text-bg-primary"'), 3)
        self.assertEqual(html.count('class="badge text-bg-secondary"'), 2)
        sales = self.client.get("/transactions/?type=sale").get_data(as_text=True)
        self.assertNotIn("Auto", sales)
        expenses = self.client.get("/transactions/?type=expense").get_data(as_text=True)
        self.assertIn("Auto", expenses)
        self.assertNotIn("Cake", expenses)
        upi = self.client.get("/transactions/?payment=UPI").get_data(as_text=True)
        self.assertIn("Cake", upi)
        self.assertNotIn("Auto", upi)
        by_profit = self.client.get("/transactions/?sort=profit&dir=asc").get_data(as_text=True)
        self.assertLess(by_profit.index("Rent"), by_profit.index("Tea"))  # biggest loss first

    def test_csv_export_matches_records(self):
        response = self.client.get("/transactions/export.csv")
        self.assertEqual(response.status_code, 200)
        self.assertIn("text/csv", response.headers["Content-Type"])
        self.assertIn("attachment", response.headers["Content-Disposition"])
        text = response.get_data(as_text=True).lstrip("\ufeff")
        rows = list(csv.reader(io.StringIO(text)))
        self.assertEqual(rows[0][:3], ["Date", "Type", "Product / Description"])
        self.assertEqual(len(rows), 6)
        profit_total = sum(float(r[8]) for r in rows[1:])
        self.assertAlmostEqual(profit_total, 119.5, places=2)  # sum of profit impacts = net profit
        report_rows = list(csv.reader(io.StringIO(
            self.client.get("/reports/export.csv?type=daily&date=%s" % self.today.isoformat()).get_data(as_text=True).lstrip("\ufeff"))))
        self.assertEqual(len(report_rows), 6)

    def test_csv_blocks_formula_injection(self):
        self.add_sale(product_name="=HYPERLINK(\"http://evil\")", customer_name="+cmd", notes="@SUM(A1)")
        text = self.client.get("/transactions/export.csv").get_data(as_text=True)
        self.assertNotIn(",=HYPERLINK", text)
        self.assertIn("'=HYPERLINK", text)
        self.assertIn("'+cmd", text)

    def test_printable_report_has_period_and_disclaimer(self):
        html = self.client.get("/reports/").get_data(as_text=True)
        self.assertIn("data-print", html)
        self.assertIn("Period:", html)
        self.assertIn("Results depend on the accuracy of the data", html)


class SettingsAndDemoTests(AppTestCase):
    def setUp(self):
        super().setUp()
        self.signup_and_login()

    def test_currency_and_date_format_apply_everywhere(self):
        self.add_sale(quantity="1", selling_price="1234567.50", cost_price="0")
        self.assertIn("\u20b912,34,567.50", self.client.get("/sales/").get_data(as_text=True))
        r = self.post(self.client, "/settings/business", {
            "business_name": "Corner Shop", "business_type": "Retail Shop", "currency": "USD",
            "address": "1 Main St", "date_format": "YYYY-MM-DD"})
        self.assertEqual(r.status_code, 302)
        page = self.client.get("/sales/").get_data(as_text=True)
        self.assertIn("$1,234,567.50", page)
        self.assertIn(date.today().isoformat(), page)
        self.assertIn("Corner Shop", page)

    def test_settings_validation(self):
        r = self.post(self.client, "/settings/business", {
            "business_name": "", "business_type": "Spaceship", "currency": "XXX",
            "address": "", "date_format": "bad"})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.query("SELECT currency FROM business_settings")[0]["currency"], "INR")

    def test_profile_and_password_change(self):
        r = self.post(self.client, "/settings/profile", {"full_name": "Alice B", "email": "alice.b@example.com"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.query("SELECT email FROM users")[0]["email"], "alice.b@example.com")
        bad = self.post(self.client, "/settings/password", {
            "current_password": "wrong", "new_password": "NewPassw0rd", "confirm_password": "NewPassw0rd"})
        self.assertEqual(bad.status_code, 400)
        ok = self.post(self.client, "/settings/password", {
            "current_password": "Passw0rd!", "new_password": "NewPassw0rd", "confirm_password": "NewPassw0rd"})
        self.assertEqual(ok.status_code, 302)
        self.assertEqual(self.login(self.new_client(), "alice", "NewPassw0rd").status_code, 302)

    def test_demo_data_load_and_safe_clear(self):
        self.add_sale(product_name="MyOwnSale")
        self.add_expense(description="MyOwnExpense")
        self.post(self.client, "/settings/demo/load")
        demo_sales = self.query("SELECT COUNT(*) AS n FROM sales WHERE is_demo = 1")[0]["n"]
        self.assertGreater(demo_sales, 50)
        self.assertGreater(self.query("SELECT COUNT(*) AS n FROM expenses WHERE is_demo = 1")[0]["n"], 5)
        self.post(self.client, "/settings/demo/load")  # second load is ignored
        self.assertEqual(self.query("SELECT COUNT(*) AS n FROM sales WHERE is_demo = 1")[0]["n"], demo_sales)
        self.post(self.client, "/settings/demo/clear")
        self.assertEqual(self.query("SELECT COUNT(*) AS n FROM sales WHERE is_demo = 1")[0]["n"], 0)
        self.assertEqual(self.query("SELECT product_name FROM sales")[0]["product_name"], "MyOwnSale")
        self.assertEqual(self.query("SELECT description FROM expenses")[0]["description"], "MyOwnExpense")

    def test_demo_data_is_consistent(self):
        from db import get_db
        from services import demo_data
        from services.profit_calculator import build_period_summary
        self.post(self.client, "/settings/demo/load")
        from models import user as user_model
        with self.app.app_context():
            db = get_db()
            uid = user_model.get_by_username(db, "alice")["id"]
            s = build_period_summary(db, uid, date.today() - timedelta(days=60), date.today())
        self.assertEqual(s["net_profit"], s["gross_profit"] - s["total_expenses"])
        self.assertEqual(s["net_sales"], s["gross_sales"] - s["discounts"])
        self.assertEqual(s["gross_profit"], s["net_sales"] - s["cogs"])


if __name__ == "__main__":
    unittest.main()
