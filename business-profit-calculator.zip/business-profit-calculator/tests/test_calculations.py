"""Pure calculation tests plus checks that totals read from the database agree."""
import unittest
from datetime import date

from tests.helpers import AppTestCase  # noqa: F401  (also puts the project on sys.path)

from services import money
from services.date_ranges import resolve_range, resolve_report_range
from services.formatting import format_money, format_quantity, group_digits, plain_amount
from services.profit_calculator import (build_period_summary, calculate_margin,
                                        calculate_summary, compute_sale_amounts)
from services.reports import build_report


def totals(count=0, gross=0, disc=0, net=0, cogs=0, gp=0):
    return {"count": count, "gross_sales": gross, "discounts": disc,
            "net_sales": net, "cogs": cogs, "gross_profit": gp}


class SaleAmountTests(unittest.TestCase):
    def test_gross_profit(self):
        # 3 x 100.00 sold, 3 x 60.00 cost
        a = compute_sale_amounts(3000, 10000, 6000, 0)
        self.assertEqual(a["gross_sales_minor"], 30000)
        self.assertEqual(a["net_sales_minor"], 30000)
        self.assertEqual(a["cogs_minor"], 18000)
        self.assertEqual(a["gross_profit_minor"], 12000)

    def test_discount_reduces_net_sales_and_profit_once(self):
        a = compute_sale_amounts(3000, 10000, 6000, 2500)
        self.assertEqual(a["net_sales_minor"], 27500)
        self.assertEqual(a["gross_profit_minor"], 27500 - 18000)

    def test_selling_below_cost_gives_negative_gross_profit(self):
        a = compute_sale_amounts(2000, 5000, 8000, 0)
        self.assertEqual(a["gross_profit_minor"], 10000 - 16000)

    def test_fractional_quantity_rounds_half_up(self):
        # 1.5 x 99.99 = 149.985 -> 149.99
        a = compute_sale_amounts(1500, 9999, 0, 0)
        self.assertEqual(a["gross_sales_minor"], 14999)

    def test_no_floating_point_drift(self):
        # 0.1 + 0.2 style trap: 3 x 0.10 must be exactly 0.30
        self.assertEqual(compute_sale_amounts(3000, 10, 0)["gross_sales_minor"], 30)
        self.assertEqual(money.parse_money("19.99"), 1999)
        self.assertEqual(money.parse_money("0.29"), 29)

    def test_discount_larger_than_gross_is_rejected(self):
        with self.assertRaises(ValueError):
            compute_sale_amounts(1000, 5000, 1000, 5001)

    def test_invalid_inputs_are_rejected(self):
        with self.assertRaises(ValueError):
            compute_sale_amounts(0, 100, 50)
        with self.assertRaises(ValueError):
            compute_sale_amounts(1000, -1, 50)


class SummaryTests(unittest.TestCase):
    def test_net_profit_and_margin(self):
        s = calculate_summary(totals(1, 30000, 0, 30000, 18000, 12000), 2000, 1)
        self.assertEqual(s["net_profit"], 10000)
        self.assertEqual(str(s["margin"]), "33.33")
        self.assertFalse(s["is_loss"])
        self.assertEqual(s["transactions"], 2)

    def test_loss_when_expenses_exceed_gross_profit(self):
        s = calculate_summary(totals(1, 30000, 0, 30000, 18000, 12000), 20000, 3)
        self.assertEqual(s["net_profit"], -8000)
        self.assertTrue(s["is_loss"])
        self.assertTrue(s["expenses_exceed_gross_profit"])
        self.assertEqual(str(s["margin"]), "-26.67")

    def test_zero_sales_has_no_margin_and_no_error(self):
        s = calculate_summary(totals(), 5000, 1)
        self.assertEqual(s["net_profit"], -5000)
        self.assertIsNone(s["margin"])
        self.assertTrue(s["is_loss"])

    def test_zero_everything(self):
        s = calculate_summary(totals(), 0, 0)
        self.assertEqual(s["net_profit"], 0)
        self.assertIsNone(s["margin"])
        self.assertFalse(s["is_loss"])
        self.assertFalse(s["expenses_exceed_gross_profit"])

    def test_cogs_and_expenses_are_each_subtracted_once(self):
        # net sales 1000, cogs 400, expenses 100 -> gross 600 -> net 500
        s = calculate_summary(totals(1, 1000, 0, 1000, 400, 600), 100, 1)
        self.assertEqual(s["gross_profit"], 600)
        self.assertEqual(s["net_profit"], 500)

    def test_margin_helper(self):
        self.assertIsNone(calculate_margin(100, 0))
        self.assertEqual(str(calculate_margin(250, 1000)), "25.00")

    def test_multiple_expenses_sum(self):
        s = calculate_summary(totals(1, 10000, 0, 10000, 4000, 6000), 1000 + 2000 + 500, 3)
        self.assertEqual(s["total_expenses"], 3500)
        self.assertEqual(s["net_profit"], 2500)


class ParsingAndFormattingTests(unittest.TestCase):
    def test_money_parsing(self):
        self.assertEqual(money.parse_money("1,249.5"), 124950)
        for bad in ("", "-5", "abc", "1.234", "1e5", "NaN", "5.", "--1"):
            with self.assertRaises(money.MoneyError, msg=bad):
                money.parse_money(bad)

    def test_quantity_parsing(self):
        self.assertEqual(money.parse_quantity("2"), 2000)
        self.assertEqual(money.parse_quantity("0.5"), 500)
        for bad in ("0", "0.000", "-1", "x", "1.2345"):
            with self.assertRaises(money.MoneyError, msg=bad):
                money.parse_quantity(bad)

    def test_currency_formatting(self):
        self.assertEqual(format_money(123456789, "INR"), "\u20b912,34,567.89")
        self.assertEqual(format_money(123456789, "USD"), "$1,234,567.89")
        self.assertEqual(format_money(-5, "INR"), "-\u20b90.05")
        self.assertEqual(format_money(0, "EUR"), "\u20ac0.00")
        self.assertEqual(group_digits("100", True), "100")
        self.assertEqual(plain_amount(-1234), "-12.34")
        self.assertEqual(format_quantity(1500), "1.5")
        self.assertEqual(format_quantity(2000), "2")


class DateRangeTests(unittest.TestCase):
    today = date(2026, 10, 23)

    def test_presets(self):
        self.assertEqual(resolve_range({"range": "today"}, self.today).start, self.today)
        y = resolve_range({"range": "yesterday"}, self.today)
        self.assertEqual((y.start, y.end), (date(2026, 10, 22), date(2026, 10, 22)))
        week = resolve_range({"range": "7d"}, self.today)
        self.assertEqual((week.start, week.end), (date(2026, 10, 17), self.today))
        month = resolve_range({"range": "30d"}, self.today)
        self.assertEqual((month.end - month.start).days, 29)

    def test_custom_and_errors(self):
        ok = resolve_range({"range": "custom", "start": "2026-10-01", "end": "2026-10-10"}, self.today)
        self.assertIsNone(ok.error)
        self.assertEqual(ok.preset, "custom")
        for args in ({"range": "custom", "start": "2026-10-10", "end": "2026-10-01"},
                     {"range": "custom", "start": "nope", "end": "2026-10-01"},
                     {"range": "custom", "start": "2020-01-01", "end": "2026-10-01"}):
            bad = resolve_range(args, self.today)
            self.assertIsNotNone(bad.error)
            self.assertEqual(bad.start, self.today)
        self.assertEqual(resolve_range({"range": "bogus"}, self.today).preset, "today")

    def test_report_ranges(self):
        weekly = resolve_report_range({"type": "weekly", "date": "2026-10-23"}, self.today)
        self.assertEqual((weekly.start, weekly.end), (date(2026, 10, 19), date(2026, 10, 25)))
        monthly = resolve_report_range({"type": "monthly", "date": "2026-02-10"}, self.today)
        self.assertEqual((monthly.start, monthly.end), (date(2026, 2, 1), date(2026, 2, 28)))
        december = resolve_report_range({"type": "monthly", "date": "2026-12-05"}, self.today)
        self.assertEqual(december.end, date(2026, 12, 31))


class DatabaseSummaryTests(AppTestCase):
    def test_summary_from_database_and_report_match(self):
        from db import get_db
        from models import expense as expense_model
        from models import sale as sale_model
        from models import user as user_model

        today = date.today()
        with self.app.app_context():
            db = get_db()
            uid = user_model.create_user(db, "calc", "calc@example.com", "Calc", "Passw0rd!")
            sale_model.create(db, uid, {
                "sale_date": today.isoformat(), "product_name": "A", "quantity_milli": 3000,
                "selling_price_minor": 10000, "cost_price_minor": 6000, "discount_minor": 1000,
                "payment_method": "Cash"})
            sale_model.create(db, uid, {
                "sale_date": today.isoformat(), "product_name": "B", "quantity_milli": 1000,
                "selling_price_minor": 5000, "cost_price_minor": 5500, "discount_minor": 0,
                "payment_method": "UPI"})
            expense_model.create(db, uid, {
                "expense_date": today.isoformat(), "category": "Rent", "description": "Rent",
                "amount_minor": 4000, "payment_method": "Cash"})
            summary = build_period_summary(db, uid, today, today)
            report = build_report(db, uid, today, today)

        # Sale A: gross 30000, discount 1000, net 29000, cogs 18000, profit 11000
        # Sale B: gross 5000, net 5000, cogs 5500, profit -500
        self.assertEqual(summary["gross_sales"], 35000)
        self.assertEqual(summary["discounts"], 1000)
        self.assertEqual(summary["net_sales"], 34000)
        self.assertEqual(summary["cogs"], 23500)
        self.assertEqual(summary["gross_profit"], 10500)
        self.assertEqual(summary["total_expenses"], 4000)
        self.assertEqual(summary["net_profit"], 6500)
        self.assertEqual(str(summary["margin"]), "19.12")
        self.assertEqual(report["summary"], summary)
        self.assertEqual(report["daily"][0]["net_profit"], 6500)


if __name__ == "__main__":
    unittest.main()
