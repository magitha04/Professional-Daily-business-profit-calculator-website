/* Dashboard charts. All data comes from /dashboard/data (real database totals). */
(function () {
  "use strict";
  var host = document.getElementById("charts");
  if (!host || typeof Chart === "undefined") {
    if (host) {
      host.querySelectorAll("[data-overlay]").forEach(function (o) {
        o.textContent = "Charts couldn't load. Check your internet connection and refresh.";
        o.classList.add("show");
      });
    }
    return;
  }

  var PALETTE = ["#1f5fd1", "#0b2a55", "#5b8def", "#8fb4ff", "#2a9d8f", "#e9a23b", "#c0392b", "#7a869a"];
  var charts = {};
  var lastPayload = null;

  function colors() {
    var style = getComputedStyle(document.body);
    var dark = document.documentElement.getAttribute("data-bs-theme") === "dark";
    return { text: style.color, grid: dark ? "rgba(255,255,255,0.08)" : "rgba(11,42,85,0.08)" };
  }

  function overlay(canvasId, message) {
    var box = document.getElementById(canvasId).parentElement.querySelector("[data-overlay]");
    if (message) { box.textContent = message; box.classList.add("show"); } else { box.classList.remove("show"); }
  }

  function setLoading(isLoading) {
    host.querySelectorAll("[data-overlay]").forEach(function (box) {
      if (isLoading) {
        box.innerHTML = '<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading chart</span></div>';
        box.classList.add("show");
      } else {
        box.classList.remove("show");
      }
    });
  }

  function money(payload) {
    var fmt = new Intl.NumberFormat(payload.locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return function (value) {
      return (value < 0 ? "-" : "") + payload.currency_symbol + fmt.format(Math.abs(value));
    };
  }

  function draw(id, config) {
    if (charts[id]) { charts[id].destroy(); }
    charts[id] = new Chart(document.getElementById(id), config);
  }

  function render(payload) {
    lastPayload = payload;
    var c = colors();
    var fmt = money(payload);
    Chart.defaults.color = c.text;
    Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;
    var axis = {
      x: { grid: { display: false }, ticks: { maxTicksLimit: 10, autoSkip: true } },
      y: { grid: { color: c.grid }, ticks: { callback: function (v) { return fmt(v); } } }
    };
    var tooltip = { callbacks: { label: function (ctx) { return " " + ctx.dataset.label + ": " + fmt(ctx.parsed.y !== undefined && ctx.parsed.y !== null ? ctx.parsed.y : ctx.parsed); } } };
    var base = { responsive: true, maintainAspectRatio: false };

    draw("chartDaily", {
      type: "line",
      data: { labels: payload.daily.labels, datasets: [{
        label: "Net profit", data: payload.daily.net_profit, borderColor: "#1f5fd1",
        backgroundColor: "rgba(31,95,209,0.12)", fill: true, tension: 0.25, pointRadius: payload.daily.labels.length > 40 ? 0 : 3,
        segment: { borderColor: function (ctx) { return ctx.p1.parsed.y < 0 ? "#c0392b" : "#1f5fd1"; } }
      }] },
      options: Object.assign({}, base, { scales: axis, plugins: { legend: { display: false }, tooltip: tooltip } })
    });

    draw("chartSalesExpenses", {
      type: "bar",
      data: { labels: payload.daily.labels, datasets: [
        { label: "Sales", data: payload.daily.sales, backgroundColor: "#1f5fd1", borderRadius: 3 },
        { label: "Expenses", data: payload.daily.expenses, backgroundColor: "#e9a23b", borderRadius: 3 }
      ] },
      options: Object.assign({}, base, { scales: axis, plugins: { tooltip: tooltip } })
    });

    draw("chartMonthly", {
      type: "bar",
      data: { labels: payload.monthly.labels, datasets: [{
        label: "Net profit", data: payload.monthly.net_profit,
        backgroundColor: payload.monthly.net_profit.map(function (v) { return v < 0 ? "#c0392b" : "#1f5fd1"; }), borderRadius: 4
      }] },
      options: Object.assign({}, base, { scales: axis, plugins: { legend: { display: false }, tooltip: tooltip } })
    });

    draw("chartCategories", {
      type: "pie",
      data: { labels: payload.categories.labels, datasets: [{ data: payload.categories.values, backgroundColor: PALETTE, borderColor: getComputedStyle(document.body).backgroundColor }] },
      options: Object.assign({}, base, { plugins: { legend: { position: "bottom" }, tooltip: { callbacks: { label: function (ctx) { return " " + ctx.label + ": " + fmt(ctx.parsed); } } } } })
    });

    draw("chartProducts", {
      type: "bar",
      data: { labels: payload.products.labels, datasets: [{ label: "Units sold", data: payload.products.quantities, backgroundColor: "#0b2a55", borderRadius: 4 }] },
      options: Object.assign({}, base, { indexAxis: "y", scales: { x: { grid: { color: c.grid }, beginAtZero: true }, y: { grid: { display: false } } },
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (ctx) { return " " + ctx.parsed.x + " sold, sales " + fmt(payload.products.sales[ctx.dataIndex]); } } } } })
    });

    var empty = "No data for this period yet.";
    overlay("chartDaily", payload.has_data ? null : empty);
    overlay("chartSalesExpenses", payload.has_data ? null : empty);
    overlay("chartMonthly", payload.has_data ? null : empty);
    overlay("chartCategories", payload.categories.labels.length ? null : "No expenses in this period.");
    overlay("chartProducts", payload.products.labels.length ? null : "No sales in this period.");
  }

  setLoading(true);
  fetch(host.getAttribute("data-endpoint") + window.location.search, { headers: { Accept: "application/json" }, credentials: "same-origin" })
    .then(function (response) {
      if (!response.ok) { throw new Error("HTTP " + response.status); }
      return response.json();
    })
    .then(function (payload) { setLoading(false); render(payload); })
    .catch(function () {
      host.querySelectorAll("[data-overlay]").forEach(function (box) {
        box.textContent = "Charts couldn't load. Refresh the page to try again.";
        box.classList.add("show");
      });
    });

  document.addEventListener("themechange", function () { if (lastPayload) { render(lastPayload); } });
})();
