/* Show only the date inputs that matter for the chosen report type. */
(function () {
  "use strict";
  var select = document.getElementById("type");
  if (!select) { return; }
  function sync() {
    document.querySelectorAll("[data-for]").forEach(function (el) {
      var types = el.getAttribute("data-for").split(" ");
      el.classList.toggle("d-none", types.indexOf(select.value) === -1);
    });
  }
  select.addEventListener("change", sync);
  sync();
})();
