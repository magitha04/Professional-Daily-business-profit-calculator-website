/* Live preview on the sale form. The server recalculates everything when you save. */
(function () {
  "use strict";
  var form = document.getElementById("saleForm");
  if (!form) { return; }
  var symbol = form.getAttribute("data-currency") || "";

  function toMinor(text) {
    var clean = String(text || "").replace(/,/g, "").trim();
    if (!/^\d+(\.\d{1,2})?$/.test(clean)) { return null; }
    var parts = clean.split(".");
    return parseInt(parts[0], 10) * 100 + (parts[1] ? parseInt((parts[1] + "0").slice(0, 2), 10) : 0);
  }
  function toMilli(text) {
    var clean = String(text || "").replace(/,/g, "").trim();
    if (!/^\d+(\.\d{1,3})?$/.test(clean)) { return null; }
    var parts = clean.split(".");
    return parseInt(parts[0], 10) * 1000 + (parts[1] ? parseInt((parts[1] + "00").slice(0, 3), 10) : 0);
  }
  function scale(milli, minor) { return Math.round((milli * minor) / 1000); }
  function show(id, minor) {
    var el = document.getElementById(id);
    var negative = minor < 0;
    var abs = Math.abs(minor);
    var text = (negative ? "-" : "") + symbol + Math.floor(abs / 100).toLocaleString() + "." + String(abs % 100).padStart(2, "0");
    el.textContent = text;
    el.classList.toggle("is-negative", negative);
  }
  function update() {
    var qty = toMilli(form.quantity.value);
    var price = toMinor(form.selling_price.value);
    var cost = toMinor(form.cost_price.value);
    var discount = toMinor(form.discount.value || "0");
    if (qty === null || price === null || cost === null || discount === null) {
      ["pvGross", "pvDiscount", "pvNet", "pvCogs", "pvProfit"].forEach(function (id) { show(id, 0); });
      return;
    }
    var gross = scale(qty, price);
    var net = gross - discount;
    var cogs = scale(qty, cost);
    show("pvGross", gross);
    show("pvDiscount", discount);
    show("pvNet", net);
    show("pvCogs", cogs);
    show("pvProfit", net - cogs);
  }
  ["quantity", "selling_price", "cost_price", "discount"].forEach(function (name) {
    form[name].addEventListener("input", update);
  });
  update();
})();
