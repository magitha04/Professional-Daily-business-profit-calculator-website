/* Applies the saved light/dark theme before the page paints to avoid a flash. */
(function () {
  var theme = "light";
  try {
    var saved = window.localStorage.getItem("pc-theme");
    if (saved === "dark" || saved === "light") {
      theme = saved;
    } else if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      theme = "dark";
    }
  } catch (e) { /* storage unavailable: keep light */ }
  document.documentElement.setAttribute("data-bs-theme", theme);
})();
