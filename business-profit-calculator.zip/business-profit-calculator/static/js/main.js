/* Site-wide behaviour: toasts, theme toggle, delete confirmation, double-submit guard. */
(function () {
  "use strict";

  // Success / error notifications
  document.querySelectorAll(".toast").forEach(function (el) {
    new bootstrap.Toast(el).show();
  });

  // Light / dark mode toggle
  var toggle = document.getElementById("themeToggle");
  var icon = document.getElementById("themeIcon");
  function syncIcon() {
    if (!icon) { return; }
    var dark = document.documentElement.getAttribute("data-bs-theme") === "dark";
    icon.className = dark ? "bi bi-sun" : "bi bi-moon-stars";
  }
  syncIcon();
  if (toggle) {
    toggle.addEventListener("click", function () {
      var next = document.documentElement.getAttribute("data-bs-theme") === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-bs-theme", next);
      try { window.localStorage.setItem("pc-theme", next); } catch (e) { /* ignore */ }
      syncIcon();
      document.dispatchEvent(new CustomEvent("themechange"));
    });
  }

  // Delete confirmation modal
  var modalEl = document.getElementById("deleteModal");
  if (modalEl) {
    var modal = new bootstrap.Modal(modalEl);
    document.addEventListener("click", function (event) {
      var button = event.target.closest("[data-delete-url]");
      if (!button) { return; }
      document.getElementById("deleteForm").setAttribute("action", button.getAttribute("data-delete-url"));
      document.getElementById("deleteNext").value = button.getAttribute("data-delete-next") || "";
      document.getElementById("deleteLabel").textContent = button.getAttribute("data-delete-label") || "this record";
      modal.show();
    });
  }

  // Confirm dialogs for forms that carry data-confirm
  document.querySelectorAll("form[data-confirm]").forEach(function (form) {
    form.addEventListener("submit", function (event) {
      if (!window.confirm(form.getAttribute("data-confirm"))) { event.preventDefault(); }
    });
  });

  // Stop accidental double submits: disable the button and show a spinner
  document.querySelectorAll("form[data-prevent-double], #deleteForm").forEach(function (form) {
    form.addEventListener("submit", function (event) {
      if (event.defaultPrevented) { return; }
      if (form.dataset.submitting === "1") { event.preventDefault(); return; }
      form.dataset.submitting = "1";
      form.querySelectorAll('button[type="submit"]').forEach(function (btn) {
        btn.classList.add("is-busy");
        btn.setAttribute("aria-disabled", "true");
        var label = btn.querySelector(".btn-label");
        if (label) {
          label.insertAdjacentHTML("beforebegin", '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>');
        }
      });
    });
  });

  // Back/forward cache: make sure forms are usable again
  window.addEventListener("pageshow", function (event) {
    if (!event.persisted) { return; }
    document.querySelectorAll("form[data-submitting]").forEach(function (form) {
      delete form.dataset.submitting;
      form.querySelectorAll(".spinner-border").forEach(function (s) { s.remove(); });
      form.querySelectorAll(".is-busy").forEach(function (b) { b.classList.remove("is-busy"); b.removeAttribute("aria-disabled"); });
    });
  });

  // Print buttons
  document.querySelectorAll("[data-print]").forEach(function (btn) {
    btn.addEventListener("click", function () { window.print(); });
  });
})();
