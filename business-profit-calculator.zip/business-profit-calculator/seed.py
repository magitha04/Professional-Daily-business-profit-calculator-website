"""Create or clear demo data from the command line.

    python seed.py                       # create user "demo" with a random password
    python seed.py --username shop1 --password "MyPass123"
    python seed.py --clear --username demo
    python seed.py --clear --username demo --delete-user
"""
import argparse

from app import create_app
from db import get_db
from services import demo_data


def main():
    parser = argparse.ArgumentParser(description="Demo data tool for the Profit Calculator")
    parser.add_argument("--username", default="demo")
    parser.add_argument("--password", default=None, help="Leave empty for a random password")
    parser.add_argument("--clear", action="store_true", help="Remove demo records instead of adding them")
    parser.add_argument("--delete-user", action="store_true", help="With --clear: delete the account if empty")
    args = parser.parse_args()

    app = create_app()
    with app.app_context():
        db = get_db()
        if args.clear:
            print(demo_data.clear_demo_for_username(db, args.username, args.delete_user))
        else:
            print(demo_data.create_demo_user(db, args.username, args.password))


if __name__ == "__main__":
    main()
