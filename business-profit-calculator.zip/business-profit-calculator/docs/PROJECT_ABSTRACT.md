# Professional Daily Business Profit Calculator: project summary

## Abstract
Small business owners often track sales and costs on paper or in scattered spreadsheets, so they do not know
whether they made money today. This project is a locally hosted web application that lets an owner record each
sale (with its cost price and discount) and each operating expense, and instantly see revenue, cost of goods sold,
gross profit, net profit or loss and profit margin for any day or period. Results are shown on a dashboard with
interactive charts and in printable reports. The back end is written in Python (Flask) with an SQLite database;
the front end uses Bootstrap 5 and Chart.js. All money is handled as exact integers on the server, so figures
are reliable and consistent across every screen.

## Objectives
1. Calculate daily profit and loss accurately from user-entered sales and expenses.
2. Give every user a private, secure account and workspace.
3. Present results through a clear, responsive dashboard with real-data charts.
4. Provide searchable history, CSV export and printable reports.
5. Keep the system free, lightweight and runnable on an ordinary laptop.

## Modules
| Module | Purpose |
|---|---|
| Authentication | Registration, login, logout, sessions, password hashing, CSRF, rate limiting |
| Sales | Sale entry with live preview, edit, delete, search, filter, sort, pagination |
| Expenses | Categorised expense records with the same management tools |
| Profit calculator | One service holding every formula, used by all other modules |
| Dashboard and analytics | Summary cards, date filters, five Chart.js charts from a JSON endpoint |
| Transactions | Combined history of sales and expenses with CSV export |
| Reports | Daily, weekly, monthly, custom reports; print or PDF; CSV |
| Settings | Business profile, currency, date format, password, demo data |

## Architecture
Browser (HTML, Bootstrap, Chart.js) -> Flask blueprints (routes) -> services (validation, formulas, analytics)
-> models (parameterised SQL) -> SQLite. Routes stay thin; the formulas live in
`services/profit_calculator.py` so the dashboard, charts, history and reports cannot disagree.

## Database
`users` 1-to-1 `business_settings`; `users` 1-to-many `sales` and `expenses`. Foreign keys cascade on delete and are
enforced on every connection. Amounts are INTEGER paise/cents, quantities are thousandths.

## Testing
76 automated tests cover formulas (profit, loss, zero sales, discounts, rounding), validation, authentication,
unauthorised access, cross-user isolation, CRUD, filters, report totals matching the dashboard, CSV export and settings.

## Conclusion
The application meets the goal of giving small businesses an accurate, private and easy daily profit view using only
free tools. Correctness is protected by exact integer arithmetic, a single calculation service and automated tests.

## Future enhancements
Tax handling, percentage discounts, inventory tracking, multi-currency conversion, invoices, email password reset,
native PDF generation, mobile app, and deployment with a production server and PostgreSQL.
