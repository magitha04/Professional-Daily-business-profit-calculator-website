"""Sales records. Derived amounts are always computed here on the server."""
from services.profit_calculator import compute_sale_amounts

from .query import like_pattern, paginate

SORT_COLUMNS = {
    "date": "sale_date",
    "amount": "net_sales_minor",
    "profit": "gross_profit_minor",
    "product": "product_name COLLATE NOCASE",
}


def _record_params(clean):
    amounts = compute_sale_amounts(
        clean["quantity_milli"], clean["selling_price_minor"],
        clean["cost_price_minor"], clean["discount_minor"],
    )
    return (
        clean["sale_date"], clean["product_name"], clean["quantity_milli"],
        clean["selling_price_minor"], clean["cost_price_minor"], clean["discount_minor"],
        amounts["gross_sales_minor"], amounts["net_sales_minor"], amounts["cogs_minor"],
        amounts["gross_profit_minor"], clean["payment_method"],
        clean.get("customer_name", ""), clean.get("notes", ""),
    )


def create(db, user_id, clean, is_demo=False):
    with db:
        cursor = db.execute(
            """INSERT INTO sales (user_id, sale_date, product_name, quantity_milli,
                   selling_price_minor, cost_price_minor, discount_minor,
                   gross_sales_minor, net_sales_minor, cogs_minor, gross_profit_minor,
                   payment_method, customer_name, notes, is_demo)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (user_id,) + _record_params(clean) + (1 if is_demo else 0,),
        )
    return cursor.lastrowid


def update(db, user_id, sale_id, clean):
    with db:
        cursor = db.execute(
            """UPDATE sales SET sale_date = ?, product_name = ?, quantity_milli = ?,
                   selling_price_minor = ?, cost_price_minor = ?, discount_minor = ?,
                   gross_sales_minor = ?, net_sales_minor = ?, cogs_minor = ?,
                   gross_profit_minor = ?, payment_method = ?, customer_name = ?, notes = ?,
                   updated_at = datetime('now')
               WHERE id = ? AND user_id = ?""",
            _record_params(clean) + (sale_id, user_id),
        )
    return cursor.rowcount > 0


def get(db, user_id, sale_id):
    return db.execute(
        "SELECT * FROM sales WHERE id = ? AND user_id = ?", (sale_id, user_id)
    ).fetchone()


def delete(db, user_id, sale_id):
    with db:
        cursor = db.execute("DELETE FROM sales WHERE id = ? AND user_id = ?", (sale_id, user_id))
    return cursor.rowcount > 0


def _where(user_id, q, start, end, payment):
    where, params = ["user_id = ?"], [user_id]
    if q:
        where.append("(product_name LIKE ? ESCAPE '\\' OR customer_name LIKE ? ESCAPE '\\')")
        params += [like_pattern(q), like_pattern(q)]
    if start:
        where.append("sale_date >= ?")
        params.append(start)
    if end:
        where.append("sale_date <= ?")
        params.append(end)
    if payment:
        where.append("payment_method = ?")
        params.append(payment)
    return " AND ".join(where), params


def list_page(db, user_id, q="", start="", end="", payment="", sort="date",
              direction="desc", page=1, per_page=15):
    where, params = _where(user_id, q, start, end, payment)
    total = db.execute("SELECT COUNT(*) FROM sales WHERE " + where, params).fetchone()[0]
    pager = paginate(total, page, per_page)
    column = SORT_COLUMNS.get(sort, SORT_COLUMNS["date"])
    order = "ASC" if direction == "asc" else "DESC"
    rows = db.execute(
        "SELECT * FROM sales WHERE %s ORDER BY %s %s, id %s LIMIT ? OFFSET ?"
        % (where, column, order, order),
        params + [per_page, pager["offset"]],
    ).fetchall()
    return rows, pager


def totals(db, user_id, start, end):
    row = db.execute(
        """SELECT COUNT(*) AS count,
                  COALESCE(SUM(gross_sales_minor), 0) AS gross_sales,
                  COALESCE(SUM(discount_minor), 0) AS discounts,
                  COALESCE(SUM(net_sales_minor), 0) AS net_sales,
                  COALESCE(SUM(cogs_minor), 0) AS cogs,
                  COALESCE(SUM(gross_profit_minor), 0) AS gross_profit
           FROM sales WHERE user_id = ? AND sale_date BETWEEN ? AND ?""",
        (user_id, start.isoformat(), end.isoformat()),
    ).fetchone()
    return dict(row)


def daily(db, user_id, start, end):
    rows = db.execute(
        """SELECT sale_date AS day, COUNT(*) AS count,
                  SUM(gross_sales_minor) AS gross_sales, SUM(discount_minor) AS discounts,
                  SUM(net_sales_minor) AS net_sales, SUM(cogs_minor) AS cogs,
                  SUM(gross_profit_minor) AS gross_profit
           FROM sales WHERE user_id = ? AND sale_date BETWEEN ? AND ?
           GROUP BY sale_date""",
        (user_id, start.isoformat(), end.isoformat()),
    ).fetchall()
    return {row["day"]: dict(row) for row in rows}


def monthly(db, user_id, start, end):
    rows = db.execute(
        """SELECT substr(sale_date, 1, 7) AS month, SUM(net_sales_minor) AS net_sales,
                  SUM(gross_profit_minor) AS gross_profit
           FROM sales WHERE user_id = ? AND sale_date BETWEEN ? AND ?
           GROUP BY substr(sale_date, 1, 7)""",
        (user_id, start.isoformat(), end.isoformat()),
    ).fetchall()
    return {row["month"]: dict(row) for row in rows}


def top_products(db, user_id, start, end, limit=5):
    rows = db.execute(
        """SELECT MIN(product_name) AS product, SUM(quantity_milli) AS quantity_milli,
                  SUM(net_sales_minor) AS net_sales, SUM(gross_profit_minor) AS gross_profit
           FROM sales WHERE user_id = ? AND sale_date BETWEEN ? AND ?
           GROUP BY LOWER(product_name)
           ORDER BY SUM(quantity_milli) DESC, SUM(net_sales_minor) DESC, LOWER(product_name)
           LIMIT ?""",
        (user_id, start.isoformat(), end.isoformat(), limit),
    ).fetchall()
    return [dict(row) for row in rows]


def has_demo(db, user_id):
    return db.execute(
        "SELECT 1 FROM sales WHERE user_id = ? AND is_demo = 1 LIMIT 1", (user_id,)
    ).fetchone() is not None
