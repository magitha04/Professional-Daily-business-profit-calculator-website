"""Users and authentication."""
from werkzeug.security import check_password_hash, generate_password_hash

_DUMMY_HASH = generate_password_hash("not-a-real-password")


def create_user(db, username, email, full_name, password):
    """Create the user and their default business settings in one transaction."""
    with db:
        cursor = db.execute(
            "INSERT INTO users (username, email, full_name, password_hash) VALUES (?, ?, ?, ?)",
            (username, email, full_name, generate_password_hash(password)),
        )
        user_id = cursor.lastrowid
        db.execute("INSERT INTO business_settings (user_id) VALUES (?)", (user_id,))
    return user_id


def get_by_id(db, user_id):
    return db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


def get_by_username(db, username):
    return db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()


def exists(db, username=None, email=None, exclude_id=None):
    clauses, params = [], []
    if username is not None:
        clauses.append("username = ?")
        params.append(username)
    if email is not None:
        clauses.append("email = ?")
        params.append(email)
    sql = "SELECT 1 FROM users WHERE (" + " OR ".join(clauses) + ")"
    if exclude_id is not None:
        sql += " AND id != ?"
        params.append(exclude_id)
    return db.execute(sql, params).fetchone() is not None


def authenticate(db, login, password):
    """Return the user row when the credentials are right, otherwise None."""
    user = db.execute(
        "SELECT * FROM users WHERE username = ? OR email = ?", (login, login)
    ).fetchone()
    if user is None:
        check_password_hash(_DUMMY_HASH, password)  # keep timing similar
        return None
    return user if check_password_hash(user["password_hash"], password) else None


def update_profile(db, user_id, full_name, email):
    with db:
        db.execute("UPDATE users SET full_name = ?, email = ? WHERE id = ?", (full_name, email, user_id))


def verify_password(user, password):
    return check_password_hash(user["password_hash"], password)


def update_password(db, user_id, new_password):
    with db:
        db.execute(
            "UPDATE users SET password_hash = ? WHERE id = ?",
            (generate_password_hash(new_password), user_id),
        )


def delete_user(db, user_id):
    with db:
        db.execute("DELETE FROM users WHERE id = ?", (user_id,))
