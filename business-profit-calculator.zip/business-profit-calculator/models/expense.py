"""Operating expense records."""
from .query import like_pattern, paginate

SORT_COLUMNS = {
    "date": "expense_date",
    "amount": "amount_minor",
    "profit": "amount_minor",
    "category": "category COLLATE NOCASE",
}


def create(db, user_id, clean, is_demo=False):
    with db:
        cursor = db.execute(
            """INSERT INTO expenses (user_id, expense_date, category, description,
                   amount_minor, payment_method, notes, is_demo)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (user_id, clean["expense_date"], clean["category"], clean["description"],
             clean["amount_minor"], clean["payment_method"], clean.get("notes", ""),
             1 if is_demo else 0),
        )
    return cursor.lastrowid


def update(db, user_id, expense_id, clean):
    with db:
        cursor = db.execute(
            """UPDATE expenses SET expense_date = ?, category = ?, description = ?,
                   amount_minor = ?, payment_method = ?, notes = ?, updated_at = datetime('now')
               WHERE id = ? AND user_id = ?""",
            (clean["expense_date"], clean["category"], clean["description"],
             clean["amount_minor"], clean["payment_method"], clean.get("notes", ""),
             expense_id, user_id),
        )
    return cursor.rowcount > 0


def get(db, user_id, expense_id):
    return db.execute(
        "SELECT * FROM expenses WHERE id = ? AND user_id = ?", (expense_id, user_id)
    ).fetchone()


def delete(db, user_id, expense_id):
    with db:
        cursor = db.execute("DELETE FROM expenses WHERE id = ? AND user_id = ?", (expense_id, user_id))
    return cursor.rowcount > 0


def _where(user_id, q, start, end, payment, category):
    where, params = ["user_id = ?"], [user_id]
    if q:
        where.append("(description LIKE ? ESCAPE '\\' OR category LIKE ? ESCAPE '\\')")
        params += [like_pattern(q), like_pattern(q)]
    if start:
        where.append("expense_date >= ?")
        params.append(start)
    if end:
        where.append("expense_date <= ?")
        params.append(end)
    if payment:
        where.append("payment_method = ?")
        params.append(payment)
    if category:
        where.append("category = ?")
        params.append(category)
    return " AND ".join(where), params


def list_page(db, user_id, q="", start="", end="", payment="", category="", sort="date",
              direction="desc", page=1, per_page=15):
    where, params = _where(user_id, q, start, end, payment, category)
    total = db.execute("SELECT COUNT(*) FROM expenses WHERE " + where, params).fetchone()[0]
    pager = paginate(total, page, per_page)
    column = SORT_COLUMNS.get(sort, SORT_COLUMNS["date"])
    order = "ASC" if direction == "asc" else "DESC"
    rows = db.execute(
        "SELECT * FROM expenses WHERE %s ORDER BY %s %s, id %s LIMIT ? OFFSET ?"
        % (where, column, order, order),
        params + [per_page, pager["offset"]],
    ).fetchall()
    return rows, pager


def totals(db, user_id, start, end):
    row = db.execute(
        """SELECT COUNT(*) AS count, COALESCE(SUM(amount_minor), 0) AS total
           FROM expenses WHERE user_id = ? AND expense_date BETWEEN ? AND ?""",
        (user_id, start.isoformat(), end.isoformat()),
    ).fetchone()
    return dict(row)


def daily(db, user_id, start, end):
    rows = db.execute(
        """SELECT expense_date AS day, SUM(amount_minor) AS total
           FROM expenses WHERE user_id = ? AND expense_date BETWEEN ? AND ?
           GROUP BY expense_date""",
        (user_id, start.isoformat(), end.isoformat()),
    ).fetchall()
    return {row["day"]: row["total"] for row in rows}


def monthly(db, user_id, start, end):
    rows = db.execute(
        """SELECT substr(expense_date, 1, 7) AS month, SUM(amount_minor) AS total
           FROM expenses WHERE user_id = ? AND expense_date BETWEEN ? AND ?
           GROUP BY substr(expense_date, 1, 7)""",
        (user_id, start.isoformat(), end.isoformat()),
    ).fetchall()
    return {row["month"]: row["total"] for row in rows}


def by_category(db, user_id, start, end):
    rows = db.execute(
        """SELECT category, SUM(amount_minor) AS total, COUNT(*) AS count
           FROM expenses WHERE user_id = ? AND expense_date BETWEEN ? AND ?
           GROUP BY category ORDER BY total DESC, category""",
        (user_id, start.isoformat(), end.isoformat()),
    ).fetchall()
    return [dict(row) for row in rows]


def has_demo(db, user_id):
    return db.execute(
        "SELECT 1 FROM expenses WHERE user_id = ? AND is_demo = 1 LIMIT 1", (user_id,)
    ).fetchone() is not None
