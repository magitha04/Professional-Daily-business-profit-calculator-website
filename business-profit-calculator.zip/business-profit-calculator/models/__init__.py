"""Data access layer. Every function takes an open sqlite3 connection and a user id."""
