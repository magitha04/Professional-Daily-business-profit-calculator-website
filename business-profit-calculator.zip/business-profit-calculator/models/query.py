"""Small helpers shared by the data access modules."""


def like_pattern(text):
    """Escape LIKE wildcards so searches treat % and _ literally (use with ESCAPE '\\')."""
    escaped = text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return "%" + escaped + "%"


def paginate(total, page, per_page):
    pages = max(1, -(-total // per_page))
    page = min(max(1, page), pages)
    return {
        "page": page,
        "pages": pages,
        "total": total,
        "per_page": per_page,
        "offset": (page - 1) * per_page,
        "has_prev": page > 1,
        "has_next": page < pages,
    }
