"""Per-user business settings."""


def get(db, user_id):
    row = db.execute("SELECT * FROM business_settings WHERE user_id = ?", (user_id,)).fetchone()
    if row is None:
        with db:
            db.execute("INSERT INTO business_settings (user_id) VALUES (?)", (user_id,))
        row = db.execute("SELECT * FROM business_settings WHERE user_id = ?", (user_id,)).fetchone()
    return row


def update(db, user_id, values):
    with db:
        db.execute(
            """UPDATE business_settings
               SET business_name = ?, business_type = ?, currency = ?, address = ?,
                   date_format = ?, updated_at = datetime('now')
               WHERE user_id = ?""",
            (values["business_name"], values["business_type"], values["currency"],
             values["address"], values["date_format"], user_id),
        )
