"""Combined view of sales and expenses for the transaction history and exports."""
from .query import like_pattern, paginate

SORT_COLUMNS = {
    "date": "txn_date",
    "amount": "amount_minor",
    "profit": "profit_minor",
    "product": "title COLLATE NOCASE",
    "category": "detail COLLATE NOCASE",
}

# profit_minor is the effect on net profit: a sale's gross profit, or minus an expense.
UNION_SQL = """
SELECT 'sale' AS type, id, sale_date AS txn_date, product_name AS title,
       customer_name AS detail, quantity_milli, net_sales_minor AS amount_minor,
       discount_minor, cogs_minor, gross_profit_minor AS profit_minor,
       payment_method, notes, created_at
FROM sales WHERE user_id = ?
UNION ALL
SELECT 'expense', id, expense_date, description, category, NULL, amount_minor,
       0, 0, -amount_minor, payment_method, notes, created_at
FROM expenses WHERE user_id = ?
"""


def _where(q, start, end, kind, payment):
    where, params = ["1 = 1"], []
    if q:
        where.append("(title LIKE ? ESCAPE '\\' OR detail LIKE ? ESCAPE '\\')")
        params += [like_pattern(q), like_pattern(q)]
    if start:
        where.append("txn_date >= ?")
        params.append(start)
    if end:
        where.append("txn_date <= ?")
        params.append(end)
    if kind in ("sale", "expense"):
        where.append("type = ?")
        params.append(kind)
    if payment:
        where.append("payment_method = ?")
        params.append(payment)
    return " AND ".join(where), params


def _order(sort, direction):
    column = SORT_COLUMNS.get(sort, SORT_COLUMNS["date"])
    order = "ASC" if direction == "asc" else "DESC"
    return "ORDER BY %s %s, created_at %s, id %s" % (column, order, order, order)


def list_page(db, user_id, q="", start="", end="", kind="", payment="",
              sort="date", direction="desc", page=1, per_page=15):
    where, params = _where(q, start, end, kind, payment)
    base = "FROM (" + UNION_SQL + ") AS t WHERE " + where
    args = [user_id, user_id] + params
    total = db.execute("SELECT COUNT(*) " + base, args).fetchone()[0]
    pager = paginate(total, page, per_page)
    rows = db.execute(
        "SELECT * " + base + " " + _order(sort, direction) + " LIMIT ? OFFSET ?",
        args + [per_page, pager["offset"]],
    ).fetchall()
    return rows, pager


def list_all(db, user_id, q="", start="", end="", kind="", payment="",
             sort="date", direction="asc"):
    """Every matching record (no pagination), used for CSV export."""
    where, params = _where(q, start, end, kind, payment)
    return db.execute(
        "SELECT * FROM (" + UNION_SQL + ") AS t WHERE " + where + " " + _order(sort, direction),
        [user_id, user_id] + params,
    ).fetchall()
